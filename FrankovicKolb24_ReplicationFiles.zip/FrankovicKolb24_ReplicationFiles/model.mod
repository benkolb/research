// Parameters set in Parameters.m
parameters 
    @#include "tools/Include_Params.mod"
;
 
var 
    @#include "tools/Include_EndVars.mod"
;
 
varexo      % shock to ...
    e_aY    % ... technology in the non-energy sector
    e_aL    % ... technology in the low-carbon sector
    e_aF    % ... technology in the fossil sector 
    e_kY    % ... capital efficiency in the non-energy sector
    e_kl   	% ... capital efficiency in the low-carbon sector
    e_kf    % ... capital efficiency in the fossil sector
    e_g     % ... government spending
    e_Rn    % ... nominal interest rate    
    e_rho   % ... absconding rate
    e_n     % ... net worth
    e_tau   % ... carbon tax
    e_D     % ... disclosure    
    e_pf    % ... fossil ressource price
    e_c     % ... preference for consumption
    e_epsi  % ... price markup
    e_rhoF  % ... relative risk factor for fossil sector
    e_rhoL  % ... relative risk factor for low-carbon sector
    e_w_EL  % ... share of EL in E
    e_s_EL  % ... EL price subsidy
;
 


model;


// Marginal utility of consumption
[name = 'LAM']
LAM         = EXC*(C-hab*C(-1))^(-sig) - bet*hab*EXC(+1)*(C(+1)-hab*C)^(-sig);

// Euler equation
[name = 'R']
bet*R(+1)*LAM(+1)/LAM = 1;

// Stochastic discount rate
[name = 'M']
M = bet*LAM/LAM(-1);

// Labor market equilibrium
[name = 'L']
@#if EndLabSupply == "On"
    chi*L^fri =  LAM*W;
@#else
    L = L_SS;
@#endif 


// HH Budget Equation
B = Qk*K + QkL*KL + QkF*KF - N;
#Prof_Res    = FF*P_F;
#Prof_Q      = (Qk-1)*I + (QkF-1)*IF + (QkL-1)*IL - ACI;
#Prof_Y      = (1-MC)*Y - AC;
#Prof_Bank   = Ne/tet*(1-tet);
ResidHHBudget = W*L - G + eI_F*FF*tau - s_EL*P_EL*EL + R*B(-1) - B - C + Prof_Res + Prof_Q + Prof_Y + Prof_Bank - Nn;



// Absconding rate
rho     = rho_SS  + e_rho;
rhoF    = rhoF_SS + e_rhoF;
rhoL    = rhoL_SS + e_rhoL;

// Total return
TR = (RY(+1)-R(+1))*s  + (RL(+1)-R(+1))*sL + (RF(+1)-R(+1))*sF - acS/2*((s - s(-1))^2+(sL - sL(-1))^2+(sF - sF(-1))^2)*R(+1);

// Bank's discount factor
OME = M*(1-tet+tet*NU);

// Banks net worth
[name = 'N']
N = Ne + Nn;

// Existing banks net worth accumulation, ex-post return
[name = 'Ne']
Ne = tet*( (RY-R)*Qk(-1)*K(-1) + (RL-R)*QkL(-1)*KL(-1) + (RF-R)*QkF(-1)*KF(-1) - acS/2*((s(-1) - s(-2))^2+(sL(-1) - sL(-2))^2+(sF(-1) - sF(-2))^2)*R*SP(-1) + R*N(-1) )*exp(sig_n*e_n);

// New banks net worth
[name = 'Nn']
Nn = omg*( Qk*EXK*K(-1) + QkL*EXKL*KL(-1) + QkF*EXKF*KF(-1) )  ;

// Risk-weighted assets
[name = 'RWA']
RWA = Qk*K + rhoL*QkL*KL + rhoF*QkF*KF;

// Capital ratio
[name = 'Kappa']
Kappa = N / RWA;


Delta_V_D       = OME(+1) * (Delta_RY_D * (Qk*K) + Delta_RL_D * (QkL*KL) + Delta_RF_D * (QkF*KF) );
rhoF_Adj        = OME(+1) * Delta_RF_D / rho;

Unaccounted_Z   = eI_F*FF-eI_F_tilde*FF_tilde;

Delta_RF_D      = (EXKF(+1)*(QkF(+1)-delF)*KF + P_EF_tilde(+1)*EF_tilde(+1) - FF_tilde(+1)*P_F(+1) - tau(+1)*eI_F_tilde(+1)*FF_tilde(+1)  )/(KF*QkF) - RF(+1);
Delta_RL_D      = (EXKL(+1)*(QkL(+1)-delL)*KL + P_EL(+1)*EL(+1) - UnDisclZ_L*tau(+1)*Unaccounted_Z(+1) )/(KL*QkL)                                             - RL(+1);
Delta_RY_D      = (EXK(+1)*(Qk(+1)-del )*K + MC(+1)*Y(+1)-W(+1)*L(+1)-P_E(+1)*E(+1) - UnDisclZ_Y*tau(+1)*Unaccounted_Z(+1) )/(K*Qk)                           - RY(+1);

lambda_I*(rho*(s+rhoL*sL+rhoF*sF)) - lambda_I*OME(+1)*(Delta_RY_D*s + Delta_RL_D*sL + Delta_RF_D*sF)   = (OME(+1)*TR);


@#if FinFric == "On"

    // Leverage I
    [name = 'RY']
    rho*RWA = NU*N + Delta_RF_D; 
    
    // Expected spread 
    [name = 'ExpSpread_L']
    ExpSpread_L = RL(+1)-R(+1);
    [name = 'ExpSpread_F']
    ExpSpread_F = RF(+1)-R(+1);
    [name = 'ExpSpread_Y']
    ExpSpread_Y = RY(+1)-R(+1);

    [name = 'K'] 
    NU = OME(+1)*rho*R(+1) / (rho - rho*lambda_I);

    @#if StockSharesFixed == "Off"
        [name = 'KL']
        OME(+1) * (RL(+1)-R(+1) - acS*(sL-sL(-1))*R(+1)) + lambda_I*OME(+1)*Delta_RL_D = rhoL * ( OME(+1) * (RY(+1)-R(+1)  - acS*(s-s(-1))*R(+1)) + lambda_I*OME(+1)*Delta_RY_D );
        
        [name = 'KF']
        OME(+1) * (RF(+1)-R(+1) - acS*(sF-sF(-1))*R(+1)) + lambda_I*OME(+1)*Delta_RF_D = rhoF * ( OME(+1) * (RY(+1)-R(+1)  - acS*(s-s(-1))*R(+1)) + lambda_I*OME(+1)*Delta_RY_D );   
   @#endif

    @#if StockSharesFixed == "On"       
        [name = 'KL']
        sF = sF_SS;
        [name = 'KF']
        sL = sL_SS;  
    @#endif

    @#if StockSharesFixed == "VA Tracking"
        [name = 'KL']
        sF = sF_SS * (P_EF*EF/Y)/(P_EF_SS*EF_SS);
        [name = 'KF']
        sL = sL_SS * (P_EL*EL/Y)/(P_EL_SS*EL_SS);   
    @#endif
            
   
@#else  // NEEDS UPDATE

    // Expected spread
    ExpSpread_L = 0;
    ExpSpread_F = 0;
    //0 = OME(+1) * (ExpSpread_F - acS*(sF-sF(-1))*R(+1));
    ExpSpread_Y = 0;

    [name = 'NU']
    NU = OME(+1)*R(+1);

    [name = 'KL']
    OME(+1)*(RL(+1)-R(+1) - acS*(sL-sL(-1))*R(+1) ) = 0;
    //[name = 'KF']
    OME(+1)*(RF(+1)-R(+1) - acS*(sF-sF(-1))*R(+1) ) = 0;
    [name = 'K'] 
    OME(+1)*(RY(+1)-R(+1) - acS*(s - s(-1))*R(+1) ) = 0;

@#endif



[name = 'RY']
//RY = (EXK*(Qk-del) + MC*Y^(1/epsY)*w_CD^(1/epsY)*CD^((epsY-1)/epsY)*alf/K(-1))/Qk(-1);
RY = (EXK*(Qk-del) + (MC*Y-W*L-P_E*E)/K(-1))/Qk(-1);
[name = 'RL']
RL= (EXKL*(QkL-delL) + P_EL*EL/KL(-1))/QkL(-1);
[name = 'RF']
RF= (EXKF*(QkF-delF) + (P_EF*EF - FF*P_F - tau*eI_F*FF)/KF(-1)   )/QkF(-1);
//RF= (EXKF*(QkF-delF) + P_EF*EF^(1/epsF)*w_KF^(1/epsF)*(aF*EXAF*EXKF*KF(-1))^((epsF-1)/epsF) /KF(-1)  )/QkF(-1);



[name = 'SPR']
SPR     = RY(+1)-R(+1);
[name = 'SPRL']
SPRL    = RL(+1)-R(+1);
[name = 'SPRF']
SPRF    = RF(+1)-R(+1);


[name = 's']
s   = Qk*K   / SP;
[name = 'SL']
sL  = QkL*KL / SP;
[name = 'sF']
sF  = QkF*KF / SP;
[name = 'SP']
SP = Qk*K + QkL*KL + QkF*KF;


// Production function*
[name = 'Y'] 
Y       = ( w_CD^(1/epsY) * CD^((epsY-1)/epsY) + (1-w_CD)^(1/epsY) * E^((epsY-1)/epsY) )^(epsY/(epsY-1));

// Cobb Douglas Labor Capital composite
[name = 'CD'] 
CD          = (aY * EXA)*(EXK*K(-1))^alf*L^(1-alf);

// Wage rate
[name = 'W']
W       = MC*w_CD^(1/epsY)*CD^((epsY-1)/epsY)*(1-alf)*(Y^(1/epsY))/L;


// Energy 
[name = 'E']
E       = MC^(epsY) * (1-w_CD) * (P_E)^(-epsY) * Y;
[name = 'EL']
EL      = aL*EXAL*EXKL*KL(-1);
[name = 'EF']
EF      = EXAF*(  w_KF^(1/epsF) * (aF*EXKF*KF(-1))^((epsF-1)/epsF) + (1-w_KF)^(1/epsF) * FF^((epsF-1)/epsF) )^(epsF/(epsF-1)) ;
[name = 'EF_tilde']
EF_tilde= EXAF*(  w_KF^(1/epsF) * (aF*EXKF*KF(-1))^((epsF-1)/epsF) + (1-w_KF)^(1/epsF) * FF_tilde^((epsF-1)/epsF) )^(epsF/(epsF-1)) ;


[name = 'P_EL']
EL      = w_EL      * (P_EL*(1-s_EL)/P_E)^(-epsE) * E;
[name = 'P_EF']
EF      = (1-w_EL)  * (P_EF/P_E)^(-epsE) * E;
[name = 'P_EF_tilde']
EF_tilde= (1-w_EL)  * (P_EF_tilde/P_E)^(-epsE) * E;
[name = 'P_E']
P_E         = ( w_EL*(P_EL*(1-s_EL))^(1-epsE) + (1-w_EL)*P_EF^(1-epsE) )^(1/(1-epsE));
[name = 'w_EL']
w_EL = w_EL_SS + 0.5*(w_EL(-1)-w_EL_SS) + e_w_EL;
[name = 's_EL']
s_EL  = e_s_EL;


@#if EmissionConstraint == "Off"
    [name = 'lambda_F']
    lambda_F = 0;
    [name = 'FF']
    FF          = (1-w_KF) * ( (P_F+(tau+lambda_F)*eI_F)/P_EF)^(-epsF) * EF;
@#else
    [name = 'lambda_F']
    FF          = (1-w_KF) * ( (P_F+(tau+lambda_F)*eI_F)/P_EF)^(-epsF) * EF;
    [mcp = 'FF < 0.0321'] //0.0421*0.6
    FF          = (1-w_KF) * ( (P_F+tau*eI_F)/P_EF)^(-epsF) * EF;
@#endif


[name = 'FF_tilde']
FF_tilde    = (1-w_KF) * ( (P_F+(tau+lambda_F)*eI_F_tilde)/P_EF_tilde)^(-epsF) * EF_tilde;
[name = 'eI_F_tilde']
eI_F_tilde  = D*eI_F;
[name = 'D']
D = D_SS - e_D;
[name = 'Z']
Z = eI_F*FF;

[name = 'P_F']
P_F = P_FSS  + rho_pf*(P_F(-1)-P_FSS)   + sig_pf*e_pf;
[name = 'tau']
tau = tau_SS + rho_tau*(tau(-1)-tau_SS) + sig_tau*e_tau;




//Capital Goods Producer
[name = 'Qk']
Qk     = 1 + acI/2*(I/I(-1)-1)^2    + acI*(I/I(-1)-1)*I/I(-1)       - M(+1)*acI*(I(+1)/I-1)*(I(+1)/I)^2;
[name = 'QkL']
QkL    = 1 + acIL/2*(IL/IL(-1)-1)^2 + acIL*(IL/IL(-1)-1)*IL/IL(-1)  - M(+1)*acIL*(IL(+1)/IL-1)*(IL(+1)/IL)^2;
[name = 'QkF']
QkF    = 1 + acIF/2*(IF/IF(-1)-1)^2 + acIF*(IF/IF(-1)-1)*IF/IF(-1)  - M(+1)*acIF*(IF(+1)/IF-1)*(IF(+1)/IF)^2;
[name = 'Qk_avg']
Qk_avg = (Qk*K + rhoL*QkL*KL + rhoF*QkF*KF)/(K+rhoL*KL+rhoF*KF);

//Net investment
[name = 'ACI']
ACI = ( acI/2* ((I)/(I(-1))-1)^2*(I) + acIL/2* ((IL)/(IL(-1))-1)^2*(IL) + acIF/2*((IF)/(IF(-1))-1)^2*(IF) );

// Capital accumulation equation
[name = 'In']
K = EXK*K(-1) + I - del*EXK*K(-1);
[name = 'In_L'] 
KL = EXKL*KL(-1) + IL - delL*EXKL*KL(-1); 
[name = 'In_F'] 
KF = EXKF*KF(-1) + IF - delF*EXKF*KF(-1); 
[name = 'I_total'] 
I_total = I + IL + IF;


// Government consumption
[name = 'G']
G = GSS*EXG;

// Aggregate resource constraint
[name = 'C']
Y       = C+G+I+IL+IF+AC+ACI;

// Inflation
[name = 'MC']
0 = (1-epsI) + MC*epsI - DAC + M(+1)*DAC(+1)*(Y(+1))/Y*(Pi(+1));
[name = 'epsI']
log(epsI) = (1-rho_epsi)*log(epsI_ss) + rho_epsi*log(epsI(-1)) + sig_epsi*e_epsi;



// Adj cost
[name = 'AC']
AC = acP/2*(Pi/( Pi(-1)^w_p * (pi_SS)^(1-w_p)) - 1)^2 *Y;
[name = 'DAC']
DAC = acP*((Pi)/((Pi(-1))^w_p * (pi_SS)^(1-w_p)) - 1)*((Pi)/((Pi(-1))^w_p * (pi_SS)^(1-w_p)) );

// Interest rate rule
[name = 'Rn']
Rn          =  RnSS * (Rn(-1)/RnSS)^rho_R * (  (Pi/pi_SS)^rho_pi * (Y/Y(-1))^rho_Y )^(1-rho_R) *exp(sig_R*e_Rn);    

// Fisher equation
[name = 'Pi']
Rn = R*Pi;



//Shocks

[name = 'EXA']
log(EXA)    = rho_a*log(EXA(-1))    + sig_a*e_aY;
[name = 'EXAL']
log(EXAL)   = rho_a*log(EXAL(-1))   + sig_a*e_aL;
[name = 'EXAF']
log(EXAF)   = rho_a*log(EXAF(-1))   + sig_a*e_aF;


[name = 'EXK']
log(EXK) = rho_k*log(EXK(-1)) + sig_k*e_kY;
[name = 'EXKL']
log(EXKL) = rho_k*log(EXKL(-1)) + sig_kl*e_kl;
[name = 'EXKF']
log(EXKF) = rho_k*log(EXKF(-1)) + sig_kf*e_kf;

[name = 'EXG']
log(EXG) = rho_g*log(EXG(-1)) + sig_g*e_g;
[name = 'EXC']
log(EXC) = rho_c*log(EXC(-1)) + sig_c*e_c;



end;


verbatim;
    load('tools/Param.mat');
    pnames = M_.param_names;
    parnr  = length(pnames);
    for j = 1:parnr
       pname = deblank(pnames(j,:));
       eval(['M_.params(',num2str(j),') = ',char(pname),';'])
    end  
end;



initval;
e_tau = 0;
    @#include "tools/SS_values.mod"
end;
resid;
steady;
model_diagnostics;
check;



@#if SolvingType == "deterministic"


@#if ExoVarShocked == "On"

    @#if TauShock == "On" 
        load('Shocks/CarbonPriceEnd.mat')
        load('Shocks/CarbonPricePath.mat')
    @#endif

    @#if DisclosureShock == "On"
        load('Shocks/DisclosurePath.mat')
        load('Shocks/DisclosureEnd.mat')
    @#endif

    @#if TechShock == "On"
        load('Shocks/TechPath.mat')
        load('Shocks/TechEnd.mat')
    @#endif

    @#if FossilPriceShock == "On"
        load('Shocks/P_F_Path.mat')
        load('Shocks/P_F_End.mat')
    @#endif

    @#if rhoShock == "On"
        load('Shocks/ShockSize_rho.mat')
    @#endif

    @#if rhoFShock == "On"
        load('Shocks/ShockSize_rhoF.mat')
    @#endif 

    @#if rhoLShock == "On"
        load('Shocks/ShockSize_rhoL.mat')
    @#endif 

    @#if KapQualShock == "On"
        load('Shocks/ShockSize_KapQualF_Path.mat')
        load('Shocks/ShockSize_KapQualF_End.mat')
    @#endif

    @#if KapQualFShock == "On"
        load('Shocks/ShockSize_KapQualF_Path.mat')
        load('Shocks/ShockSize_KapQualF_End.mat')
    @#endif

    @#if WeightELShock == "On"
        load('Shocks/WeightEL_Path.mat')
        load('Shocks/WeightEL_End.mat')
    @#endif
  
    @#if SubsELShock == "On"
        load('Shocks/SubsEL_Path.mat')
        load('Shocks/SubsEL_End.mat')
    @#endif


    shocks;

    @#if TauShock == "On" 
        var e_tau;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (CarbonPricePath);
    @#endif

    @#if DisclosureShock == "On"
        var e_D;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (DisclosurePath);
    @#endif

    @#if TechShock == "On"
        var e_aF;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (TechPath);
    @#endif

    @#if FossilPriceShock == "On"
        var e_pf;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (P_F_Path);
    @#endif

    @#if rhoShock == "On"
        var e_rho;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (ShockSize_rho);
    @#endif

    @#if rhoFShock == "On"
        var e_rhoF;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (ShockSize_rhoF);
    @#endif

    @#if rhoLShock == "On"
        var e_rhoL;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (ShockSize_rhoL);
    @#endif

    @#if KapQualShock == "On"
        var e_kY;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (ShockSize_KapQual_Path);
    @#endif

    @#if KapQualFShock == "On"
        var e_kf;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (ShockSize_KapQualF_Path);
    @#endif

    @#if WeightELShock == "On"
        var e_w_EL;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (WeightEL_Path);
    @#endif

    @#if SubsELShock == "On"
        var e_s_EL;
        @#if LongHorizon == "Off"
            periods 1:120;
        @#endif
        @#if LongHorizon == "On"
            periods 1:160;
        @#endif
        values (SubsEL_Path);
    @#endif

    end;

    endval;
        @#if TauShock == "On" 
            e_tau = (CarbonPriceEnd);
        @#endif

        @#if DisclosureShock == "On"
            e_D = (DisclosureEnd);
        @#endif

        @#if TechShock == "On"
            e_aF = (TechEnd);
        @#endif

        @#if FossilPriceShock == "On"
            e_pf = (P_F_End);
        @#endif

        @#if rhoShock == "On"
            e_rho = (ShockSize_rho);
        @#endif

        @#if rhoFShock == "On"
            e_rhoF = (ShockSize_rhoF);
        @#endif

        @#if rhoLShock == "On"
            e_rhoL = (ShockSize_rhoL);
        @#endif

        @#if KapQualShock == "On"
            e_kY = (ShockSize_KapQual_End);
        @#endif

        @#if KapQualFShock == "On"
            e_kf = (ShockSize_KapQualF_End);
        @#endif

        @#if WeightELShock == "On"
            e_w_EL = (WeightEL_End);
        @#endif

        @#if SubsELShock == "On"
            e_s_EL = (SubsEL_End);
        @#endif

    end;

    homotopy_setup;
        @#if TauShock == "On" 
            e_tau, 0, (CarbonPriceEnd);
        @#endif

        @#if DisclosureShock == "On"
            e_D, 0, (DisclosureEnd);
        @#endif

        @#if TechShock == "On"
            e_aF, 0, (TechEnd);
        @#endif

        @#if FossilPriceShock == "On"
            e_pf, 0, (P_F_End);
        @#endif

        @#if rhoShock == "On"
            e_rho, 0, (ShockSize_rho);
        @#endif

        @#if rhoFShock == "On"
            e_rhoF, 0, (ShockSize_rhoF);
        @#endif

        @#if rhoLShock == "On"
            e_rhoL, 0, (ShockSize_rhoL);
        @#endif

        @#if KapQualShock == "On"
            e_kY, 0, (ShockSize_KapQual_End);
        @#endif

        @#if KapQualFShock == "On"
            e_kf, 0, (ShockSize_KapQualF_End);
        @#endif

        @#if WeightELShock == "On"
            e_w_EL, 0, (WeightEL_End);
        @#endif

        @#if SubsELShock == "On"
            e_s_EL, 0, (SubsEL_End);
        @#endif
    end;

    @#if LongHorizon == "Off"
        steady(homotopy_mode = 1, homotopy_steps = 100 , solve_algo=0);
    @#endif
    @#if LongHorizon == "On"
        steady(homotopy_mode = 1, homotopy_steps = 100, solve_algo=0);
    @#endif
    resid;
@#endif



    @#if LongHorizon == "Off"
        perfect_foresight_setup(periods=200);
    @#endif
    @#if LongHorizon == "On"
        perfect_foresight_setup(periods=200);
    @#endif

    
    @#if solve_algo == "10"
        perfect_foresight_solver(robust_lin_solve,stack_solve_algo=7,solve_algo=10);
    @#endif
    @#if solve_algo == "0"
        //perfect_foresight_solver(robust_lin_solve,stack_solve_algo=0);
        perfect_foresight_solver(stack_solve_algo=0);
    @#endif 
    @#if solve_algo == "rob0"
        perfect_foresight_solver(robust_lin_solve,stack_solve_algo=0);
    @#endif  

@#endif



@#if AddUnanticipated_tauShock == "On"

    load('Shocks/T_UAtau.mat')

    load('Shocks/CarbonPriceEnd_true.mat')
    load('Shocks/CarbonPricePath_true.mat')

    // Declare unexpected shock 
    oo_.exo_simul(T_UAtau:end, 7) = [CarbonPricePath_true(T_UAtau:end) CarbonPriceEnd_true*ones(1,42)]; // Period 20 has index 21!

    // Strip first n periods and save them
    saved_endo = oo_.endo_simul(:, 1:T_UAtau-2); // Save periods 0 to n-1
    saved_exo = oo_.exo_simul(1:T_UAtau-2, :);
    oo_.endo_simul = oo_.endo_simul(:, T_UAtau-1:end); // Keep periods n to 301
    oo_.exo_simul = oo_.exo_simul(T_UAtau-1:end, :);

    @#if LongHorizon == "Off"
        periods 197;
    @#endif
    @#if LongHorizon == "On"
        periods 197;
    @#endif
    
    perfect_foresight_solver;

    // Combine the two simulations
    oo_.endo_simul = [ saved_endo oo_.endo_simul ];
    oo_.exo_simul = [ saved_exo; oo_.exo_simul ];



@#endif



@#if AddUnanticipatedShock == "On"

    // for three years 3*4 + 1 =  13
    // for 1.5 year 13 becomes 7, 12 becomes 6, 11 becomes 5
    // for 1   year 13 becomes 5, 12 becomes 4, 11 becomes 3
    // for 0.5 year 13 becomes 3, 12 becomes 2, 11 becomes 1

    // Declare unexpected shock 
    oo_.exo_simul(13:end, 12) = -0.2; // Period 20 has index 21!

    // Strip first n periods and save them
    saved_endo = oo_.endo_simul(:, 1:11); // Save periods 0 to n-1
    saved_exo = oo_.exo_simul(1:11, :);
    oo_.endo_simul = oo_.endo_simul(:, 12:end); // Keep periods n to 301
    oo_.exo_simul = oo_.exo_simul(12:end, :);

    periods 189; //200-11

    
    perfect_foresight_solver;

    // Combine the two simulations
    oo_.endo_simul = [ saved_endo oo_.endo_simul ];
    oo_.exo_simul = [ saved_exo; oo_.exo_simul ];



@#endif


@#if SolvingType == "stochastic"
    check;
    steady;
    model_diagnostics;

    options_.pruning        = 1;
    options_.relative_irf   = 1;
    options_.nocorr         = 1;
    options_.nomoments      = 1;
    options_.noprint        = 1;
    options_.nograph        = 0;
    options_.simul_seed     = 42;

    shocks;
        var e_aY    = 0;
        var e_kY    = 0; 
        var e_kl    = 0;
        var e_kf    = 0;
        var e_g     = 0; 
        var e_n     = 0; 
        var e_tau   = 0;
        var e_c     = 0;
        var e_epsi  = 1;
    end;

    // to plot remove nograph and add varnames to the right
    stoch_simul(order=2, periods=2000, irf=40); 

@#endif


