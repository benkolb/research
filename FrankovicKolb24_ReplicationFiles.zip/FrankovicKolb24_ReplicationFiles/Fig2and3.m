
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure 2 and 3: disclosure ("D") shock in isolation
% Note: This file can take up to an hour to run.

clear; close all force; clc;
addpath('tools');

tic

%% set some parameters
nvar = 9;   % # variables
nhor = 41;  % # horizons

epsE_Values = linspace(1.5,4.5,3); 
epsY_Values = linspace(0.5,0.7,3); 
epsF_Values = linspace(0.1,0.2,3); 
tauSS_Values = [50;75;100];

nd = length(epsE_Values)*length(epsF_Values)*length(epsY_Values); 

GDP_impact_Dshock       = zeros(200,41);
Parameter_choice_Dshock = {};
irf_array_Dshock        = nan(nd,nhor,nvar);
IRF_save_Dshock = {};


%% run simulations
i_Sim = 1;
SimName   = 'delete';
number_nondet_solutions = 0;

for i_epsE = 1:length(epsE_Values)
    for i_epsF  = 1:length(epsF_Values)
        for i_epsY = 1:length(epsY_Values)
            for i_tau = 1:length(tauSS_Values)


                % -----------------------------------------------------------------
                [SS,Parameters,DynareMacroVars] = prepareSimulation;
                initial_D           = 0.8;
                Parameters.tau_SS   = tauSS_Values(i_tau);
                Parameters.epsE     = epsE_Values(i_epsE);
                Parameters.epsF     = epsF_Values(i_epsF);
                Parameters.epsY     = epsY_Values(i_epsY);
                DynareMacroVars.TauShock        = 'Off';
                DynareMacroVars.DisclosureShock = 'On';
                DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
                DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
                try
                    % RunModel_bk
                    RunModel
                    IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
                    format long
                    SS_D          = Simulation.IrfVectors(:,end); % save('Shocks/SS_D.mat','SS_D')

                    % D shock from lower initial D steady state to 100%
                    [SS,Parameters,DynareMacroVars] = prepareSimulation;
                    initial_D           = 0.8;
                    Parameters.tau_SS   = tauSS_Values(i_tau);
                    Parameters.epsE     = epsE_Values(i_epsE);
                    Parameters.epsF     = epsF_Values(i_epsF);
                    Parameters.epsY     = epsY_Values(i_epsY);
                    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
                    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
                    Parameters.D_SS     = IRFS_D_SS_run.D(end);
                    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
                    Manual_SS           = SS_D;
                    DynareMacroVars.recalculateSS = 0;
                    DynareMacroVars.TauShock = 'Off';
                    DynareMacroVars.DisclosureShock = 'On';
                    D_Shock = -(1-initial_D);
                    DisclosurePath  = [linspace(D_Shock,D_Shock,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
                    DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
                    % RunModel_bk
                    RunModel

                    % -----------------------------------------------------------------
                    
                    % BK: collect all variables needed for figure with D shock only:
                    irf_array_Dshock(i_Sim,:,:) = [...
                        400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRF(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)),... fossil sector spread in ann. bps dev from SS
                        400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRL(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)),... low-carbon sector spread in ann. bps dev from SS
                        400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPR(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)),... non-energy sector spread in ann. bps dev from SS
                        100*(Simulation.IrfVectorsAsStruct.QkF(1:41)-Simulation.IrfVectorsAsStruct.QkF(1))/Simulation.IrfVectorsAsStruct.QkF(1),... fossil assets' Tobin's Q in % dev from SS
                        100*(Simulation.IrfVectorsAsStruct.IF(1:41)-Simulation.IrfVectorsAsStruct.IF(1))/Simulation.IrfVectorsAsStruct.IF(1),... fossil investment in % dev from SS
                        100*(Simulation.IrfVectorsAsStruct.IL(1:41)-Simulation.IrfVectorsAsStruct.IL(1))/Simulation.IrfVectorsAsStruct.IL(1),... green investment in % dev from SS
                        100*(Simulation.IrfVectorsAsStruct.Z(1:41)-Simulation.IrfVectorsAsStruct.Z(1))/Simulation.IrfVectorsAsStruct.Z(1),... Emissions in % dev from SS
                        100*(Simulation.IrfVectorsAsStruct.Y(1:41)-Simulation.IrfVectorsAsStruct.Y(1))/Simulation.IrfVectorsAsStruct.Y(1),... GDP in % dev from SS
                        100*(Simulation.IrfVectorsAsStruct.Kappa(1:41)-Simulation.IrfVectorsAsStruct.Kappa(1))... BCR in PP dev from SS
                        ];
                    IRF_save_Dshock{i_Sim} = Simulation.IrfVectorsAsStruct;
                    Parameter_choice_taushock{i_Sim} = struct('epsE', epsE_Values(i_epsE),'epsF', epsE_Values(i_epsF), 'epsY', epsY_Values(i_epsY),'tauSS', tauSS_Values(i_tau));
                    i_Sim = i_Sim+1;

                catch
                    % no model solution
                    Parameter_noSol(i_Sim,:) = [epsE_Values(i_epsE) epsY_Values(i_epsY) epsF_Values(i_epsF) tauSS_Values(i_tau)];

                end

            end
        end
    end
end



%% plot responses with bands
nh = 24;                        % # quarters plotted
prctls = [50 16 84 5 95 5 95];  % percentiles of draws that are plotted
colour = [0, 98, 161]/255;      % define color of irfs
colour2 = [0.850 0.325 0.098];  % define second color of irfs

xtick_years = (0:6)*4;


% titles and axis labels for spread effect figures
vtit1 = {...
    {'Fossil spread'; '$E_t \{ R^F_{t+1}-R_t \}$'},...
    {'Low-carbon spread'; '$E_t \{ R^L_{t+1}-R_t \}$'},...
    {'Non-energy spread'; '$E_t \{ R^Y_{t+1}-R_t \}$'}...
    };
vlab1 = {...
    'ann. bps from SS'...
    'ann. bps from SS'...
    'ann. bps from SS'...
    };

% titles and axis labels for macro effect figures
vtit2 = {...
    'Fossil capital asset price $Q^F_t$',...
    'Fossil investment $I^F_t$',...
    'Low-carbon investment $I^L_t$',...
    'Emissions $Z_t$',...
    'GDP $Y_t$',...
    'Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab2 = {...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    'PP from SS'...
    };

% titles and axis labels for DIFFERENTIAL macro effect figures
vtit3 = {...
    '$\Delta$ Fossil capital asset price $Q^F_t$',...
    '$\Delta$ Fossil investment $I^F_t$',...
    '$\Delta$ Low-carbon investment $I^L_t$',...
    '$\Delta$ Emissions $E_t$',...
    '$\Delta$ GDP $Y_t$',...
    '$\Delta$ Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab3 = {...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.'...
    };
ytik3 = {{-1.5:0.3:0},...
    {[-6,-4,-2,0]},...
    {0:4},...
    {-0.3:0.1:0.1},...
    {0:0.03:0.12},...
    {-0.15:0.15:0.55},...
    };

% generate plots for D shock only (Fig 2 and 3)
% take percentiles
irf_D = sort(irf_array_Dshock,1);
irf_D_prct = prctile(irf_array_Dshock,prctls);
pos_baseline = round(size(irf_array_Dshock,1)/2); % baseline always in centre for strictly symmetric arrays!

% plot responses of spreads
t = 1:nh+1;
figure('name','Spread responses to D shock')
nv = numel(vtit1);
for vv = 1:nv
    subplot(3,3,vv)
    ir = irf_D_prct(:,1:nh+1,vv);
    h2 = area([ir(6,:)',ir(4,:)'-ir(6,:)',ir(2,:)'-ir(4,:)',ir(3,:)'-ir(2,:)',ir(5,:)'-ir(3,:)',ir(7,:)'-ir(5,:)']);%,'FaceColor',[.85 .85 .85]);
    set(h2(6),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(5),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(4),'FaceColor',colour,'FaceAlpha',0.4)
    set(h2(3),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(2),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(1),'FaceColor',colour,'FaceAlpha',0)
    set(h2,'linestyle','none'); hold on
    h3 = plot(t,irf_array_Dshock(pos_baseline,1:nh+1,vv),'Color',colour,'LineWidth',2); hold on;
    plot(t,zeros(nh+1,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    %xlim([0 24])
    title(vtit1{vv},'interpreter','latex');
    ylabel(vlab1{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 2; legend([h2(3),h2(4)],'90%','68%','Location','SouthEast','Box','off'); end
    if vv > 1; ylim([-50 0]); yticks(-50:10:0); end
    xlim([1 24])
end
saveas(gcf,'figures/Fig2.pdf');


% plot responses of macro variables
t = 1:nh+1;
figure('name','Macro responses to D shock')
nv = numel(vtit2);
for vv = 1:nv
    subplot(3,3,vv)
    ir = irf_D_prct(:,1:nh+1,vv+3); % start after spreads
    h2 = area([ir(6,:)',ir(4,:)'-ir(6,:)',ir(2,:)'-ir(4,:)',ir(3,:)'-ir(2,:)',ir(5,:)'-ir(3,:)',ir(7,:)'-ir(5,:)']);
    set(h2(6),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(5),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(4),'FaceColor',colour,'FaceAlpha',0.4)
    set(h2(3),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(2),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(1),'FaceColor',colour,'FaceAlpha',0) 
    set(h2,'linestyle','none'); hold on
    plot(t,irf_array_Dshock(pos_baseline,1:nh+1,vv+3),'Color',colour,'LineWidth',2); hold on;
    plot(t,zeros(nh+1,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    title(vtit2{vv},'interpreter','latex');
    ylabel(vlab2{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 6; legend([h2(3),h2(4)],'90%','68%','Location','NorthEast','Box','off'); end
    ylim([min(cell2mat(ytik3{vv})) max(cell2mat(ytik3{vv}))])
    yticks(cell2mat(ytik3{vv}))
    xlim([1 24])
end
saveas(gcf,'figures/Fig3.pdf');

toc



