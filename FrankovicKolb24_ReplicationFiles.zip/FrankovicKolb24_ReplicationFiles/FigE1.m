
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure E.1: Effect of disclosure with carbon tax following Hotelling Rule


clear; close all force; clc;
addpath('tools');


%% set some parameters
tau_SS = 75; 
tau_SS_text = num2str(tau_SS);
Tau_Shock_Size  = 50;

initial_D = 0.8;
D_text = num2str(initial_D);
D_text = D_text([1,3]); %remove dots


%% run the simulations
% tau shock from D=1
SimName                         = ['SS_sim_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);        save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel
IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
format long
SS_D          = Simulation.IrfVectors(:,end);

growth_rate = log(125/75)/24;
rise_path = 75*exp(growth_rate*linspace(1,24,24))-75; %starting at 75 and rising by 2 % over 24q
tau_path_hotelling = [rise_path rise_path(end)*ones(1,120-24)];


% rising tau shock from lower initial D steady state
SimName = ['Hotelling_tauShock_SS_D',D_text,'_tauSS',tau_SS_text]; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = tau_path_hotelling;    save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);  save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel 

% rising tau and D  shock from lower initial D steady state to 1
SimName = ['Hotelling_tauShock_DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = tau_path_hotelling;    save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);  save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel 



%% plot responses
nh = 24;                        % # quarters plotted
colour = [0, 98, 161]/255;      % define color of irfs
colour2 = [0.850 0.325 0.098];  % define second color of irfs

xtick_years = (0:6)*4;
vtit = {...
    'Fossil capital asset price $Q^F_t$',...
    'Fossil investment $I^F_t$',...
    'Low-carbon investment $I^L_t$',...
    'Emissions $Z_t$',...
    'GDP $Y_t$',...
    'Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab = {...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    'PP from SS'...
    };
ytik = {{-15:5:0},...
    {-80:20:0},...
    {0:50:150},...
    {-25:5:0},...
    {-0.4:0.2:0.6},...
    {-1:1:3},...
    };
XX1 = load('simulations/Hotelling_tauShock_SS_D08_tauSS75');
XX2 = load('simulations/Hotelling_tauShock_DisclShock_SS_D08_tauSS75.mat');
vnam = {'QkF','IF','IL','Z','Y','Kappa'};
vadj = {'ptc','ptc','ptc','ptc','ptc','100'};
irfs1 = nan(nh,numel(vnam));
irfs2 = irfs1;
for vv = 1:numel(vnam)
    x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
    x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
    if strcmp(vadj{vv},'ptc')
        x1  = 100.*(x1-x1(1))./x1(1);
        x2  = 100.*(x2-x2(1))./x2(1);
    elseif strcmp(vadj{vv},'100')
        x1 = 100.*(x1-x1(1));
        x2 = 100.*(x2-x2(1));
    end
    irfs1(:,vv) = x1;
    irfs2(:,vv) = x2;
end

t = 1:nh;
figure('name','Macro responses to tau (and D) shock')
nv = numel(vtit);
for vv = 1:nv
    subplot(3,3,vv)
    plot(t,irfs1(:,vv),'Color',colour2,'LineWidth',2); hold on;
    plot(t,irfs2(:,vv),'Color',colour,'LineWidth',2,'LineStyle','--'); hold on;
    plot(t,zeros(nh,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    title(vtit{vv},'interpreter','latex');
    ylabel(vlab{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 6; legend('$D=0.8$','$D=1$','interpreter','latex','Location','NorthEast','Box','off'); end
    ylim([min(cell2mat(ytik{vv})) max(cell2mat(ytik{vv}))])
    yticks(cell2mat(ytik{vv}))
    xlim([1 20])
end
saveas(gcf,'figures/FigE1.pdf');




