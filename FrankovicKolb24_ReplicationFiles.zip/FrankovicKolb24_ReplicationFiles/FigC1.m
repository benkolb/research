
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure C.1: difference carbon tax ("tau") shock in isolation versus carbon
% tax and disclosure shock ("two shock") case.
% Note: This file can take more than an hour to run.

clear; close all force; clc;
addpath('tools');

tic

%% set some parameters
nvar = 9;   % # variables
nhor = 41;  % # horizons
Tau_Shock_Size  = 50; % increase in carbon tax tau

epsE_Values = linspace(1.5,4.5,3);
epsY_Values = linspace(0.5,0.7,3);
epsF_Values = linspace(0.1,0.2,3);
tauSS_Values = [50;75;100];
% epsF_Values = 0.15;
% tauSS_Values = 75;
% epsE_Values = 3;
% epsY_Values = 0.6;

nd = length(epsE_Values)*length(epsF_Values)*length(epsY_Values)*length(tauSS_Values);

irf_array_taushock        = nan(nd,nhor,nvar);
irf_array_twoshock        = irf_array_taushock;


%% run simulations
i_Sim = 1;
SimName   = 'delete';
Parameter_noSol = nan(nd,4); % save parameter combinations for which at least one model has no solution
wb = waitbar(0,['Taking ' num2str(nd) ' parameter draws...']);

% return i_epsE=1; i_epsF=1; i_epsY=1; i_tau=1;

for i_epsE = 1:length(epsE_Values)
    for i_epsF  = 1:length(epsF_Values)
        for i_epsY = 1:length(epsY_Values)
            for i_tau = 1:length(tauSS_Values)


                % ---------------------------------------------------------
                % First, only tau shock (carbon tax and D=0.8)

                tau_SS = tauSS_Values(i_tau);
                tau_SS_text = num2str(tau_SS);
                initial_D = 0.8;
                D_text = num2str(initial_D);
                D_text = D_text([1,3]);

                % Get new steady state with lower D
                SimName                         = ['SS_sim_D',D_text,'_tauSS',tau_SS_text];
                [SS,Parameters,DynareMacroVars] = prepareSimulation;
                Parameters.tau_SS   = tauSS_Values(i_tau);
                Parameters.epsE     = epsE_Values(i_epsE);
                Parameters.epsF     = epsF_Values(i_epsF);
                Parameters.epsY     = epsY_Values(i_epsY);

                DynareMacroVars.TauShock        = 'Off';
                DynareMacroVars.DisclosureShock = 'On';
                DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
                DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
                try
                RunModel
                IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
                format long
                SS_D          = Simulation.IrfVectors(:,end);

                % tau shock from lower initial D steady state
                SimName = ['tauShock_SS_D',D_text,'_tauSS',tau_SS_text];
                [SS,Parameters,DynareMacroVars] = prepareSimulation;
                Parameters.tau_SS   = tauSS_Values(i_tau);
                Parameters.epsE     = epsE_Values(i_epsE);
                Parameters.epsF     = epsF_Values(i_epsF);
                Parameters.epsY     = epsY_Values(i_epsY);
                Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
                Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
                Parameters.D_SS     = IRFS_D_SS_run.D(end);
                Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
                Manual_SS           = SS_D;
                DynareMacroVars.recalculateSS = 0;
                CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
                CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
                % RunModel


                % check if tau-shock case has determ. solution:
                    RunModel_no_homotopy
        
                    % -----------------------------------------------------------------

                    % store simulation results in case there is a solution also for tau-shock case:
                    Simulation_tau_shocks = Simulation;


                    % -----------------------------------------------------------------
                    % Second, check if a determ. solution is found for case of two shocks (tau and D=1)
            
                    % tau and D  shock from lower initial D steady state to 1
                    SimName = ['tauShock_DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
                    [SS,Parameters,DynareMacroVars] = prepareSimulation;
                    Parameters.tau_SS   = tauSS_Values(i_tau);
                    Parameters.epsE     = epsE_Values(i_epsE);
                    Parameters.epsF     = epsF_Values(i_epsF);
                    Parameters.epsY     = epsY_Values(i_epsY);
                    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
                    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
                    Parameters.D_SS     = IRFS_D_SS_run.D(end);
                    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
                    Manual_SS           = SS_D;
                    DynareMacroVars.recalculateSS = 0;
                    CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
                    CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
                    DynareMacroVars.DisclosureShock = 'On';
                    DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
                    DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
        
                    try
                        RunModel_no_homotopy
    
                        % -----------------------------------------------------------------

                        % BK: collect all IRFs for tau shock only:
                        irf_array_twoshock(i_Sim,:,:) = [...
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRF(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)),... fossil sector spread in ann. bps dev from SS
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRL(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)),... low-carbon sector spread in ann. bps dev from SS
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPR(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)),... non-energy sector spread in ann. bps dev from SS
                            100*(Simulation.IrfVectorsAsStruct.QkF(1:41)-Simulation.IrfVectorsAsStruct.QkF(1))/Simulation.IrfVectorsAsStruct.QkF(1),... fossil assets' Tobin's Q in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.IF(1:41)-Simulation.IrfVectorsAsStruct.IF(1))/Simulation.IrfVectorsAsStruct.IF(1),... fossil investment in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.IL(1:41)-Simulation.IrfVectorsAsStruct.IL(1))/Simulation.IrfVectorsAsStruct.IL(1),... green investment in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Z(1:41)-Simulation.IrfVectorsAsStruct.Z(1))/Simulation.IrfVectorsAsStruct.Z(1),... Emissions in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Y(1:41)-Simulation.IrfVectorsAsStruct.Y(1))/Simulation.IrfVectorsAsStruct.Y(1),... GDP in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Kappa(1:41)-Simulation.IrfVectorsAsStruct.Kappa(1))... BCR in PP dev from SS
                            ];
                        % BK: also collect all IRFs for two shocks:
                        Simulation = Simulation_tau_shocks;
                        irf_array_taushock(i_Sim,:,:) = [...
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRF(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRF(1)),... fossil sector spread in ann. bps dev from SS
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPRL(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPRL(1)),... low-carbon sector spread in ann. bps dev from SS
                            400*100*(Simulation.IrfVectorsAsStruct.R(1:41)+Simulation.IrfVectorsAsStruct.SPR(1:41)-(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)))/(Simulation.IrfVectorsAsStruct.R(1)+Simulation.IrfVectorsAsStruct.SPR(1)),... non-energy sector spread in ann. bps dev from SS
                            100*(Simulation.IrfVectorsAsStruct.QkF(1:41)-Simulation.IrfVectorsAsStruct.QkF(1))/Simulation.IrfVectorsAsStruct.QkF(1),... fossil assets' Tobin's Q in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.IF(1:41)-Simulation.IrfVectorsAsStruct.IF(1))/Simulation.IrfVectorsAsStruct.IF(1),... fossil investment in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.IL(1:41)-Simulation.IrfVectorsAsStruct.IL(1))/Simulation.IrfVectorsAsStruct.IL(1),... green investment in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Z(1:41)-Simulation.IrfVectorsAsStruct.Z(1))/Simulation.IrfVectorsAsStruct.Z(1),... Emissions in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Y(1:41)-Simulation.IrfVectorsAsStruct.Y(1))/Simulation.IrfVectorsAsStruct.Y(1),... GDP in % dev from SS
                            100*(Simulation.IrfVectorsAsStruct.Kappa(1:41)-Simulation.IrfVectorsAsStruct.Kappa(1))... BCR in PP dev from SS
                            ];

                    catch
                        % do nothing -- "outer" catch below will document error
                    end

                catch
                    % one of the two simulations has no determ. solution:
                    Parameter_noSol(i_Sim,:) = [epsE_Values(i_epsE) epsY_Values(i_epsY) epsF_Values(i_epsF) tauSS_Values(i_tau)];
                end

                i_Sim = i_Sim+1;
                waitbar(i_Sim/nd,wb)

            end
        end
    end
end

close(wb)
toc

% to check number of accepted parameter draws: 
% sum(isnan(Parameter_noSol(:,1)))



%% plot responses with bands
nh = 24;                        % # quarters plotted
prctls = [50 16 84 5 95 5 95];  % percentiles of draws that are plotted
colour = [0, 98, 161]/255;      % define color of irfs
colour2 = [0.850 0.325 0.098];  % define second color of irfs

xtick_years = (0:6)*4;


% titles and axis labels for DIFFERENTIAL macro effect figures
vtit = {...
    '$\Delta$ Fossil capital asset price $Q^F_t$',...
    '$\Delta$ Fossil investment $I^F_t$',...
    '$\Delta$ Low-carbon investment $I^L_t$',...
    '$\Delta$ Emissions $Z_t$',...
    '$\Delta$ GDP $Y_t$',...
    '$\Delta$ Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab = {...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.',...
    'PP dev.'...
    };



%% generate plots for difference two shocks and only tau shock (Fig 7)

% The difference between the IRFs gives the marginal effect of improving
% disclosure:
irf_diff = irf_array_twoshock - irf_array_taushock;
irf_diff_prct = prctile(irf_diff,prctls);


%% plot responses of macro variables
t = 1:nh+1;
figure('name','Diff in macro responses two shocks vs tau shock only')
nv = numel(vtit);
for vv = 1:nv
    subplot(3,3,vv)
    ir = irf_diff_prct(:,1:nh+1,vv+3); % start after spreads
    h2 = area([ir(6,:)',ir(4,:)'-ir(6,:)',ir(2,:)'-ir(4,:)',ir(3,:)'-ir(2,:)',ir(5,:)'-ir(3,:)',ir(7,:)'-ir(5,:)']);
    set(h2(6),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(5),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(4),'FaceColor',colour,'FaceAlpha',0.4)
    set(h2(3),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(2),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(1),'FaceColor',colour,'FaceAlpha',0)
    set(h2,'linestyle','none'); hold on
    % median is ordered first:
    plot(t,irf_diff_prct(1,1:nh+1,vv+3),'Color',colour,'LineWidth',2); hold on;
    plot(t,zeros(nh+1,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    title(vtit{vv},'interpreter','latex');
    ylabel(vlab{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 6; legend([h2(3),h2(4)],'90%','68%','Location','NorthEast','Box','off'); end
    % keep ylims tight for readability; only add yticks where necessary:
    if vv == 3; ylim([0 8]); yticks(0:2:8); end
    if vv == 6; ylim([-.25 .5]); yticks(-.25:.25:.5); end
    xlim([1 24])
end
saveas(gcf,'figures/FigC1.pdf');








return


%% plot difference in responses of spreads

% titles and axis labels for spread effect figures
vtit1 = {...
    '\Delta Fossil spread $R^F_t-R_t$',...
    '\Delta Low-carbon spread $R^L_t-R_t$',...
    '\Delta Non-energy spread $R^Y_t-R_t$'...
    };
vlab1 = {...
    'ann. bps from SS'...
    'ann. bps from SS'...
    'ann. bps from SS'...
    };

t = 1:nh+1;
figure('name','Diff in spread responses two shocks vs tau shock only')
nv = numel(vtit1);
for vv = 1:nv
    subplot(3,3,vv)
    ir = irf_diff_prct(:,1:nh+1,vv); % start after spreads
    h2 = area([ir(6,:)',ir(4,:)'-ir(6,:)',ir(2,:)'-ir(4,:)',ir(3,:)'-ir(2,:)',ir(5,:)'-ir(3,:)',ir(7,:)'-ir(5,:)']);
    set(h2(6),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(5),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(4),'FaceColor',colour,'FaceAlpha',0.4)
    set(h2(3),'FaceColor',colour,'FaceAlpha',0.2)
    set(h2(2),'FaceColor',colour,'FaceAlpha',0.1)
    set(h2(1),'FaceColor',colour,'FaceAlpha',0)
    set(h2,'linestyle','none'); hold on
    % median is ordered first:
    plot(t,irf_diff_prct(1,1:nh+1,vv),'Color',colour,'LineWidth',2); hold on;
    plot(t,zeros(nh+1,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    xlim([1 24])
    title(vtit2{vv},'interpreter','latex');
    ylabel(vlab2{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 6; legend([h2(3),h2(4)],'90%','68%','Location','NorthEast','Box','off'); end
end


