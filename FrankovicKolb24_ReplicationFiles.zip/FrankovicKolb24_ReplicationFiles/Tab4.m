
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Table 4: Sensitivity analysis for some core parameters/variables

clear; close all force; clc;
addpath('tools');

tic


%% some settings
Perform_RobustnessSim_Discl = 1;
Plot_RobustnessSim_Discl = 1;
Tau_Shock_Size  = 50;
tau_SS = 75;
res = nan(9,6); % collect results here


%% simulate for each parameter constellation
% for Ni = 1:2%length(RobustnessRunNames)

    % has to be in loop, otherwise overwritten
    RobustnessRuns.baseline = {{'epsY','0.6'}};
    RobustnessRuns.Rob_epsY_low  = { {'epsY', '0.4'} };
    RobustnessRuns.Rob_epsY_high = { {'epsY', '0.8'} };
    RobustnessRuns.Rob_epsE_low = { {'epsE', '1.5'} };
    RobustnessRuns.Rob_epsE_high= { {'epsE', '5'} };
    RobustnessRuns.Rob_epsF_low = { {'epsF', '0.075'} };
    % steady-state problems with epsF=0.3 exactly
    RobustnessRuns.Rob_epsF_high ={ {'epsF', '0.3'} };
    % "zeta" parameter (for legacy reasons called "UnDiscloZ_L" here):
    RobustnessRuns.Rob_UndZ_low  = { {'UnDisclZ_L', '0'},{'UnDisclZ_Y', '1'} };
    RobustnessRuns.Rob_UndZ_high = { {'UnDisclZ_L', '1'},{'UnDisclZ_Y', '0'} };

    RobustnessRunNames = fieldnames(RobustnessRuns);

    %{

    initial_D = 0.8;
    tau_SS= 75;
    SimName                         = 'SS_sim_D08_tauSS75';
    [SS,Parameters,DynareMacroVars] = prepareSimulation;
    Parameters.tau_SS = tau_SS;
    % change params
    Robustness_Run_Specification = RobustnessRuns.(RobustnessRunNames{Ni});
    for i=1:length(Robustness_Run_Specification)
        SetParamStatement = strcat('Parameters.',Robustness_Run_Specification{i}{1},'=',num2str(Robustness_Run_Specification{i}{2}),';');
        eval(SetParamStatement)
    end
    DynareMacroVars.recalculateSS = 1;
    DynareMacroVars.TauShock        = 'Off';
    DynareMacroVars.DisclosureShock = 'On';
    DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
    DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
    RunModel
    IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
    format long
    SS_D          = Simulation.IrfVectors(:,end);

    % tau shock from lower initial D steady state
    SimName = 'tauShock_SS_D08_tauSS75';
    [SS,Parameters,DynareMacroVars] = prepareSimulation;
    Parameters.tau_SS   = tau_SS;
    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
    Parameters.D_SS     = IRFS_D_SS_run.D(end);
    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
    Manual_SS           = SS_D;
    DynareMacroVars.recalculateSS = 0;
    CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
    CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
    RunModel


    % tau and D  shock from lower initial D steady state to 1
    SimName = 'tauShock_DisclShock_SS_D08_tauSS75';
    [SS,Parameters,DynareMacroVars] = prepareSimulation;
    Parameters.tau_SS   = tau_SS;
    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
    Parameters.D_SS     = IRFS_D_SS_run.D(end);
    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
    Manual_SS           = SS_D;
    DynareMacroVars.recalculateSS = 0;
    CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
    CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
    DynareMacroVars.DisclosureShock = 'On';
    DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
    DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
    RunModel

    clear RobustnessRuns


    %% obtain values for respective table row
    nh = 25; % horizon of interest (6 years)
    XX1 = load('simulations/tauShock_SS_D08_tauSS75.mat');
    XX2 = load('simulations/tauShock_DisclShock_SS_D08_tauSS75.mat');

    res(Ni,:) = [...
        100*(XX1.IrfVectors(strcmp(XX1.M_.endo_names,'Y'),nh) - SS_D(strcmp(XX1.M_.endo_names,'Y')))/SS_D(strcmp(XX1.M_.endo_names,'Y')),...
        100*(XX2.IrfVectors(strcmp(XX1.M_.endo_names,'Y'),nh) - SS_D(strcmp(XX1.M_.endo_names,'Y')))/SS_D(strcmp(XX1.M_.endo_names,'Y')),...
        100*(XX1.IrfVectors(strcmp(XX1.M_.endo_names,'IL'),nh) - SS_D(strcmp(XX1.M_.endo_names,'IL')))/SS_D(strcmp(XX1.M_.endo_names,'IL')),...
        100*(XX2.IrfVectors(strcmp(XX1.M_.endo_names,'IL'),nh) - SS_D(strcmp(XX1.M_.endo_names,'IL')))/SS_D(strcmp(XX1.M_.endo_names,'IL')),...
        100*(XX1.IrfVectors(strcmp(XX1.M_.endo_names,'Z'),nh) - SS_D(strcmp(XX1.M_.endo_names,'Z')))/SS_D(strcmp(XX1.M_.endo_names,'Z')),...
        100*(XX2.IrfVectors(strcmp(XX1.M_.endo_names,'Z'),nh) - SS_D(strcmp(XX1.M_.endo_names,'Z')))/SS_D(strcmp(XX1.M_.endo_names,'Z')),...
        ];

end



%% display content of Table 4
clc
disp('----------------------------------------------------------------------')
disp(['          ' '   GDP tax   ' '   GDP D     ' '   LCI tax   ' '   LCI D     ' '   Emi tax   ' '   Emi D     ' ])
disp('----------------------------------------------------------------------')
disp(['BL        ' num2str(res(1,:),'%.2f')])
disp(['epsY=0.4  ' num2str(res(2,:),'%.2f')])
disp(['epsY=0.8  ' num2str(res(3,:),'%.2f')])
disp(['epsE=1.5  ' num2str(res(4,:),'%.2f')])
disp(['epsE=5    ' num2str(res(5,:),'%.2f')])
disp(['epsF=0.075' num2str(res(6,:),'%.2f')])
disp(['epsF=0.3  ' num2str(res(7,:),'%.2f')])
disp(['zeta=1    ' num2str(res(8,:),'%.2f')])
disp(['zeta=0    ' num2str(res(9,:),'%.2f')])
disp('----------------------------------------------------------------------')

toc




return
    %}

%%

Tau_Shock_Size  = 50;
CarbonPricePath = Tau_Shock_Size*ones(1,120); save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd = CarbonPricePath(end); save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')

% Tax Runs
for Ni = 1:length(RobustnessRunNames)

    % Get new steady state with lower D
    SimName                         = strcat('SS_sim_D08_',RobustnessRunNames{Ni})
    [SS,Parameters,DynareMacroVars] = prepareSimulation;

    % change params
    Robustness_Run_Specification = RobustnessRuns.(RobustnessRunNames{Ni});
    for i=1:length(Robustness_Run_Specification)
        SetParamStatement = strcat('Parameters.',Robustness_Run_Specification{i}{1},'=',num2str(Robustness_Run_Specification{i}{2}),';')
        eval(SetParamStatement)
    end
    DynareMacroVars.recalculateSS = 1;
    DynareMacroVars.TauShock        = 'Off';
    DynareMacroVars.DisclosureShock = 'On';
    DisclosurePath  = (1-0.8)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
    DisclosureEnd   = DisclosurePath(end);  save('Shocks/DisclosureEnd.mat','DisclosureEnd')
    RunModel
    IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
    format long
    SS_D          = Simulation.IrfVectors(:,end);


    % tau shock from lower initial D steady state
    SimName = strcat('tauShock_SS_D08_',RobustnessRunNames{Ni})
    % take over parameters from above
    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
    Parameters.D_SS     = IRFS_D_SS_run.D(end);
    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
    Manual_SS           = SS_D;
    DynareMacroVars.recalculateSS = 0;
    DynareMacroVars.TauShock        = 'On';
    DynareMacroVars.DisclosureShock = 'Off';
    % carbon price shock from above
    RunModel

    % tau and D  shock from lower initial D steady state to 1
    SimName = strcat('tauShock_DisclShock_SS_D08_',RobustnessRunNames{Ni})
    % take over parameters from above
    Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
    Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
    Parameters.D_SS     = IRFS_D_SS_run.D(end);
    Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
    Manual_SS           = SS_D;
    DynareMacroVars.recalculateSS = 0;
    % carbon price shock from above
    DynareMacroVars.DisclosureShock = 'On';
    DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
    DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
    RunModel

end






% Legend = {'All to non-energy','Benchmark, proportional to size','All to low-carbon'};


GDP_effect = zeros(3,1);
IL_effect = zeros(3,1);
FF_effect = zeros(3,1);

Add_GDP_effect = zeros(3,1);
Add_IL_effect = zeros(3,1);
Add_FF_effect = zeros(3,1);

NPV_GDP = zeros(3,1);
GDP_EA_2022=3.4; %Trillions


for Ni = 1:length(RobustnessRunNames)

    SimulationPath  = strcat('simulations/tauShock_SS_D08_',RobustnessRunNames{Ni},'.mat');
    Results         = load(SimulationPath);
    IRFs_Tax_only   = Results.IrfVectorsAsStruct;

    SimulationPath  = strcat('simulations/tauShock_DisclShock_SS_D08_',RobustnessRunNames{Ni},'.mat');
    Results         = load(SimulationPath);
    IRFs_Tax_plus_D = Results.IrfVectorsAsStruct;

    Horizon = 6*4+1; % after six years
    GDP_effect(Ni) =  100*(IRFs_Tax_only.Y(Horizon) - IRFs_Tax_only.Y(1))/IRFs_Tax_only.Y(1);
    GDP_cost_IRFs_Tax_plus_D =  100*(IRFs_Tax_plus_D.Y(Horizon) - IRFs_Tax_plus_D.Y(1))/IRFs_Tax_plus_D.Y(1);

    CompoundInterestRate_Tax_only   = ones(25,1);
    CompoundInterestRate_Tax_plus_D = ones(25,1);
    for i=2:25
        CompoundInterestRate_Tax_only(i)    = CompoundInterestRate_Tax_only(i-1)   * 1/IRFs_Tax_only.R(i);
        CompoundInterestRate_Tax_plus_D(i)  = CompoundInterestRate_Tax_plus_D(i-1) * 1/IRFs_Tax_plus_D.R(i);
    end
    NPV_GDP_Tax_only        = sum(GDP_EA_2022*IRFs_Tax_only.Y(1:25) .* CompoundInterestRate_Tax_only);
    NPV_GDP_Tax_Tax_plus_D  = sum(GDP_EA_2022*IRFs_Tax_plus_D.Y(1:25) .* CompoundInterestRate_Tax_plus_D);
    NPV_GDP(Ni)             = NPV_GDP_Tax_Tax_plus_D-NPV_GDP_Tax_only;


    IL_effect(Ni)    =  100*(IRFs_Tax_only.IL(Horizon) - IRFs_Tax_only.IL(1))/IRFs_Tax_only.IL(1);
    IL_IRFs_Tax_plus_D  =  100*(IRFs_Tax_plus_D.IL(Horizon) - IRFs_Tax_plus_D.IL(1))/IRFs_Tax_plus_D.IL(1);

    FF_effect(Ni)    =  100*(IRFs_Tax_only.FF(Horizon) - IRFs_Tax_only.FF(1))/IRFs_Tax_only.FF(1);
    FF_IRFs_Tax_plus_D  =  100*(IRFs_Tax_plus_D.FF(Horizon) - IRFs_Tax_plus_D.FF(1))/IRFs_Tax_plus_D.FF(1);



    Add_GDP_effect(Ni) = ((GDP_cost_IRFs_Tax_plus_D-GDP_effect(Ni)));
    Add_IL_effect(Ni) = ((IL_IRFs_Tax_plus_D-IL_effect(Ni)));
    Add_FF_effect(Ni) = ((FF_IRFs_Tax_plus_D-FF_effect(Ni)));



end


GDP_tax = round(GDP_effect,2);
IL_tax = round(IL_effect,2);
Z_tax = round(FF_effect,2);

GDP_Disc = round(Add_GDP_effect,2);
IL_Disc = round(Add_IL_effect,2);
Z_Disc = round(Add_FF_effect,2);

format short
% Table shows additional impact on GDP, IL and FF
% A value of 0.10 in GDP row means that adding the disclosure shock
% increases the GDP impact of the carbon tax shock by 0.11 % of initial GDP
Legend = [...
    'BL        ';...
    'epsY=0.4  ';...
    'epsY=0.8  ';...
    'epsE=1.5  ';...
    'epsE=5    ';...
    'epsF=0.075';...
    'epsF=0.3  ';...
    'zeta=1    ';
    'zeta=0    '];
Table = table(Legend,GDP_tax,GDP_Disc,IL_tax,IL_Disc,Z_tax,Z_Disc) % NPV_GDP,


