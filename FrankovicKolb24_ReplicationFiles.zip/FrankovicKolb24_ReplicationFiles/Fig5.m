
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure 5: interaction disclosure vs financial frictions with carbon tax 
% (The file creates both Figure 5a and 5b in the paper.)

clear; close all force; clc;
addpath('tools');


%% set some parameters

tau_SS = 75;
tau_SS_text = num2str(tau_SS);

Tau_Shock_Size  = 50;

initial_D = 0.8;
D_text = num2str(initial_D);
D_text = D_text([1,3]); % remove dots


%% run the simulations
% 1. D=1 case
% 1a) Get new steady state with lower D  
SimName                         = ['SS_sim_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel
IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
format long
SS_D          = Simulation.IrfVectors(:,end);

% 1b) tau shock from lower initial D steady state
SimName = ['tauShock_SS_D',D_text,'_tauSS',tau_SS_text]; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel 

% 1c) tau and D  shock from lower initial D steady state to 1
SimName = ['tauShock_DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel 

% 2. No financial frictions case

tau_SS = 75;
tau_SS_text = num2str(tau_SS);

% tau shock from D=1
SimName = ['tauShock_tauSS',tau_SS_text]; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel 

% tau shock with no financial frictions
SimName   = ['tauShock_tauSS',tau_SS_text,'_noFinFric']; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
DynareMacroVars.FinFric = 'Off';
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
Parameters.SPRSS  = 0;
Parameters.SPRFSS = 0;
Parameters.SPRLSS = 0;
RunModel


%% plot responses
nh = 24;                        % # quarters plotted
colour = [0, 98, 161]/255;      % define color of irfs
colour2 = [0.850 0.325 0.098];  % define second color of irfs

MatlabColors=[  0         0.4470    0.7410;
                0.8500    0.3250    0.0980;
                0         0.5020         0;
                0.6       0.6       0.6   ;
                0.4660    0.6740    0.1880;
                0.3010    0.7450    0.9330;
                0.6350    0.0780    0.1840];

xtick_years = (0:6)*4;
vtit2 = {...
    'Fossil capital asset price $Q^F_t$',...
    'Fossil investment $I^F_t$',...
    'Low-carbon investment $I^L_t$',...
    'Emissions $E_t$',...
    'GDP $Y_t$',...
    'Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab2 = {...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    '\% from SS',...
    'PP from SS'...
    };
XX1 = load('simulations/tauShock_SS_D08_tauSS75.mat');
XX2 = load('simulations/tauShock_DisclShock_SS_D08_tauSS75.mat');
vnam = {'QkF','IF','IL','Z','Y','Kappa'};
vadj = {'ptc','ptc','ptc','ptc','ptc','100'};
irfs1 = nan(nh,numel(vnam));
irfs2 = irfs1;
for vv = 5%1:nv
    x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
    x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
    if strcmp(vadj{vv},'ptc')
        x1  = 100.*(x1-x1(1))./x1(1);
        x2  = 100.*(x2-x2(1))./x2(1);
    elseif strcmp(vadj{vv},'100')
        x1 = 100.*(x1-x1(1));
        x2 = 100.*(x2-x2(1));
    end
    irfs1(:,vv) = x1;
    irfs2(:,vv) = x2;
end

t = 1:nh;
figure('name','tau shock without and with disclosure shock')
nv = numel(vtit2);
for vv = 5%1:nv
    subplot(3,3,vv)
    plot(t,irfs1(:,vv),'Color',colour2,'LineWidth',2); hold on;
    plot(t,irfs2(:,vv),'Color',colour,'LineWidth',2,'LineStyle','--'); hold on;
    plot(t,zeros(nh,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    title(vtit2{vv},'interpreter','latex');
    ylabel(vlab2{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 5; legend('$D=0.8$','$D=1$','interpreter','latex','Location','NorthEast','Box','off'); end
    yticks(-0.75:0.25:0)
    ylim([-0.75 0])
    xlim([1 24])
end
saveas(gcf,'figures/Fig5a.pdf');


XX1 = load('simulations/tauShock_tauSS75.mat');
XX2 = load('simulations/tauShock_tauSS75_noFinFric.mat');
irfs1 = nan(nh,numel(vnam));
irfs2 = irfs1;
for vv = 5%1:nv
    x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
    x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
    if strcmp(vadj{vv},'ptc')
        x1  = 100.*(x1-x1(1))./x1(1);
        x2  = 100.*(x2-x2(1))./x2(1);
    elseif strcmp(vadj{vv},'100')
        x1 = 100.*(x1-x1(1));
        x2 = 100.*(x2-x2(1));
    end
    irfs1(:,vv) = x1;
    irfs2(:,vv) = x2;
end

t = 1:nh;
figure('name','tau shock with and without financial frictions')
nv = numel(vtit2);
for vv = 5%1:nv
    subplot(3,3,vv)
    plot(t,irfs1(:,vv),'Color',MatlabColors(3,:),'LineWidth',2); hold on;
    plot(t,irfs2(:,vv),'Color',MatlabColors(5,:),'LineWidth',2,'LineStyle','--'); hold on;
    plot(t,zeros(nh,1),'k--')
    xticks(xtick_years);
    xticklabels(xtick_years/4)
    title(vtit2{vv},'interpreter','latex');
    ylabel(vlab2{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 5; legend('with FF','no FF','interpreter','latex','Location','NorthEast','Box','off'); end
    yticks(-0.75:0.25:0)
    ylim([-0.75 0])
    xlim([1 24])
end
saveas(gcf,'figures/Fig5b.pdf');




