
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure 1: elasticity financing costs fossil sector to steady-state carbon 
% tax rate tau and disclosure D.

clear; close all force; clc;
addpath('tools');

tic


%% set some parameters
tau_SS_Loop  = 30:5:150; 
D_Shock_Loop = 0.1:0.1:0.4; 


%% Steady-state analysis
            
for i_tau=1:length(tau_SS_Loop)

    String_to_Execute = ['All_IRFS_', num2str(i_tau)  ,' = {};'];
    eval(String_to_Execute)

    for i_D=1:length(D_Shock_Loop)
        SimName                         = ['D_Shock_ii' num2str(i_D)];
        [SS,Parameters,DynareMacroVars] = prepareSimulation;
        Parameters.tau_SS =  tau_SS_Loop(i_tau);
        DynareMacroVars.TauShock = 'Off';
        DynareMacroVars.DisclosureShock = 'On';
        ShockSize_D = D_Shock_Loop(i_D);
        DisclosurePath = [linspace(ShockSize_D,ShockSize_D,120)]; save('Shocks/DisclosurePath.mat','DisclosurePath')
        DisclosureEnd = DisclosurePath(end); save('Shocks/DisclosureEnd.mat','DisclosureEnd')
        RunModel
        
        String_to_Execute = ['All_IRFS_', num2str(i_tau)  ,' =  [All_IRFS_', num2str(i_tau)  , ', Simulation.IrfVectorsAsStruct];'];
        eval(String_to_Execute)
    end

end

% Add annualized versions
RF_Spread_Change_according_to_BK = [0 -0.32 -0.7 -1.1 -1.6];

x_Loop = tau_SS_Loop;

RF_Spread_Change = zeros(length(tau_SS_Loop),length(D_Shock_Loop));

for i_tau=1:length(tau_SS_Loop) 

    String_to_Execute = ['All_IRFS = All_IRFS_', num2str(i_tau)  ,';'];
    eval(String_to_Execute)

    for i_D=1:length(D_Shock_Loop)
          
        Pi_SS                       = (All_IRFS{i_D}.Pi(1)^4 - 1)*100;
        RF_ann_SS                   = (All_IRFS{i_D}.RF(1)^4- 1) * 100 +Pi_SS;
        RF_ann_end                  = (All_IRFS{i_D}.RF(end)^4- 1) * 100 +Pi_SS;
        RF_Spread_Change(i_tau,i_D) = RF_ann_end - RF_ann_SS;

    end

end


%% plot results
BK23 = nan(size(x_Loop)); BK21=BK23; KV21 = BK23; KP21=BK23;
BK23(2:4)   = 0.79;
BK21(9:15)  = 1.97;
KP21(13:20) = 2.69;
KV21(14:21) = 2.74;
figure('name','Frankovic/Kolb Fig. 1')
hold on
% note: invert as RF_Spread_Change is effect of D being lowered
plot(x_Loop,100*(-1)*RF_Spread_Change(:,1)/10,'LineWidth',3,'LineStyle','--','Color',"#4DBEEE" ), hold on
plot(x_Loop,100*(-1)*RF_Spread_Change(:,2)/20,'LineWidth',3,'LineStyle','-','Color',"#0072BD")
plot(x_Loop,100*(-1)*RF_Spread_Change(:,3)/30,'LineWidth',3,'LineStyle','--','Color',"#000099")
plot(x_Loop,100*(-1)*RF_Spread_Change(:,4)/40,'LineWidth',3,'LineStyle','-','Color',"#374D7F")
plot(x_Loop,BK23,'LineWidth',2,'LineStyle',':','Color',"#F55820")
plot(x_Loop,BK21,'LineWidth',2,'LineStyle','-.','Color',"#D42B20")
plot(x_Loop,KP21,'LineWidth',2,'LineStyle',':','Color',"#EB2F8D")
plot(x_Loop,KV21,'LineWidth',2,'LineStyle','-.','Color',"#BF20D4")
plot(75,1.6616,'.','MarkerSize',30,'Color','g'), hold off 
xline(75,'--',{'75€ / ton';'(baseline)'}) 
xline(50,'--','50€ / ton') 
xline(100,'--','100€ / ton') 
xline(125,'--','125€ / ton') 
hold off
ylabel({'Change in financing costs $R^F$ (bps p.a.)';' per PP change in disclosure $D$'}, 'FontSize', 15,'interpreter','latex') 
xlim([min(x_Loop),max(x_Loop)])
ylim([0,5])
xlabel('Steady-state carbon tax rate $\tau$', 'FontSize', 15, 'interpreter','latex')
legend( '$D=0.9$',...
        '$D=0.8$ (BL)',...
        '$D=0.7$',...
        '$D=0.6$',...
        'BK23',...'Bolton/Kacperczyk (2023 JoF)',...
        'BK21b',...'Bolton/Kacperczyk (2021 JFE)',...
        'KP21',...'Kacperczyk/Peydró (2021 CEPR WP)',...
        'KV21',...'Kleimeier/Viehs (2021 EL)',...
        'BL $\tau$ and $D$',...
        'Location','southeast','FontSize',10,'interpreter','latex','EdgeColor','None')
exportgraphics(gcf,'figures/Fig1.pdf')


toc

