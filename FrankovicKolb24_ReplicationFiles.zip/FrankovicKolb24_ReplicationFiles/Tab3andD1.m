
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Table 3 and D.1: Effects on GDP of disclosure and/or carbon tax shocks,
% after 3 years and 6 years, respectively.
% Note: You might have to scroll up in command window in order to see 
% output for Table 6.1.

clear; close all force; clc;
addpath('tools');

tic


%% Overview Table

% run model with 50 euro carbon tax shock:
Tau_Shock_Size  = 50;
tau_SS = 75;
tau_SS_text = num2str(tau_SS);

initial_D = 0.8;
D_text = '08';

disp(['Running for tau_SS = ',tau_SS_text,' and D = ', D_text])

% Get new steady state with lower D
SimName                         = 'SS_sim_D08_tauSS75';
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel
IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
format long
SS_D          = Simulation.IrfVectors(:,end);

% tau shock from lower initial D steady state
SimName = 'tauShock50_SS_D08_tauSS75';
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS   = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0;
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel

% D shock from lower initial D steady state to 100%
SimName = ['DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0;
DynareMacroVars.TauShock = 'Off';
DynareMacroVars.DisclosureShock = 'On';
D_Shock = -(1-initial_D);
DisclosurePath  = [linspace(D_Shock,D_Shock,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel


% D shock from lower initial D to 10% more disclosure
SimName = ['DisclShock_SS_D',D_text,'_tauSS',tau_SS_text,'_10percMoreD'];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0;
DynareMacroVars.TauShock = 'Off';
DynareMacroVars.DisclosureShock = 'On';
D_Shock = -(initial_D/10);
DisclosurePath  = [linspace(D_Shock,D_Shock,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel




% run shocks with only 25 euro carbon shock:

tau_SS = 75;
tau_SS_text = num2str(tau_SS);

initial_D = 0.8;
D_text = num2str(initial_D);
D_text = D_text([1,3]); %remove dots

Tau_Shock_Size = 25;

% Get new steady state with lower D
SimName                         = ['SS_sim_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel
IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
format long
SS_D          = Simulation.IrfVectors(:,end);

% tau shock from lower initial D steady state
SimName = ['tauShock25_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0;
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel


% tau and D  shock from lower initial D steady state to 1
SimName = 'tauShock25_DisclShock_SS_D08_tauSS75';
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0;
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel


Tau_Shock_Size = 50;
SimName = ['tauShock_DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = Tau_Shock_Size*ones(1,120);   save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end);         save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel 

%% load required simulation results:
% carbon tax shocks with D=0.8:
tauShock25_SS_D08_tauSS75 = load('simulations\tauShock25_SS_D08_tauSS75');
tauShock50_SS_D08_tauSS75 = load('simulations\tauShock50_SS_D08_tauSS75');
% only disclosure shock (D=0.1):
DisclShock_SS_D08_tauSS75 = load('simulations\DisclShock_SS_D08_tauSS75');
% carbon tax shocks and disclosure shock:
tauShock25_DisclShock_SS_D08_tauSS75 = load('simulations\tauShock25_DisclShock_SS_D08_tauSS75');
tauShock50_DisclShock_SS_D08_tauSS75 = load('simulations\tauShock_DisclShock_SS_D08_tauSS75');



%% calculate figures for effect after 6 years:
GDP = 13427; % EA GDP in 2022 in bn €
end_period = 25;
% 1) Effect higher carbon taxes on GDP (D=0.8)
gdp100_D08_pct = 100*(tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp100_D08_bnE = gdp100_D08_pct/100*GDP;
gdp125_D08_pct = 100*(tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp125_D08_bnE = gdp125_D08_pct/100*GDP;
% 2) Effect higher carbon taxes on GDP (D=1)
gdp100_D10_pct = 100*(tauShock25_DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp100_D10_bnE = gdp100_D10_pct/100*GDP;
gdp125_D10_pct = 100*(tauShock50_DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp125_D10_bnE = gdp125_D10_pct/100*GDP;
% 3) Differential effect higher carbon taxes on GDP (2)-1))
gdp75_D08to10_pct  = 100*(DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp75_D08to10_bnE  = gdp75_D08to10_pct/100*GDP;
gdp100_D08to10_pct = gdp100_D10_pct - gdp100_D08_pct;
gdp100_D08to10_bnE = gdp100_D10_bnE - gdp100_D08_bnE;
gdp125_D08to10_pct = gdp125_D10_pct - gdp125_D08_pct;
gdp125_D08to10_bnE = gdp125_D10_bnE - gdp125_D08_bnE;
% 4) Effect higher carbon taxes on carbon tax revenue
% 100*tau*Z/Y gives impact on carbon tax revenue in percent
taxrev75_pct = 100*75*SS_D(strcmp(M_.endo_names,'Y'))*SS_D(strcmp(M_.endo_names,'Z'));
taxrev75_bnE = GDP*taxrev75_pct/100;
taxrev100_pct_incr = 100*100*tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Z(end_period)*tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period) - taxrev75_pct;
taxrev100_bnE_incr = GDP*taxrev100_pct_incr/100;
taxrev125_pct_incr = 100*125*tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Z(end_period)*tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period) - taxrev75_pct;
taxrev125_bnE_incr = GDP*taxrev125_pct_incr/100;


% replicate Table 3 for horizon of 6 instead of 3 years
disp('       ---- TABLE D.1 ----')
disp('----------------------------------------------------------------------')
disp(['Carbon Tax in €/ton ','        75       ','       100       ','       125       '])
disp('----------------------------------------------------------------------')
disp(['D = 0.8 (bn €)      ','      13,427     ','      ' num2str(gdp100_D08_bnE,'%.1f') '      ','      ' num2str(gdp125_D08_bnE,'%.1f') '      '])
disp(['D = 0.8 (% GDP)     ','       100%      ','       ' num2str(gdp100_D08_pct,'%.3f') '%   ','       ' num2str(gdp125_D08_pct,'%.3f') '%   '])
disp(['D = 1.0 (bn €)      ','       +' num2str(gdp75_D08to10_bnE,'%.1f') '      ','      ' num2str(gdp100_D10_bnE,'%.1f') '      ','      ' num2str(gdp125_D10_bnE,'%.1f') '      '])
disp(['D = 1.0 (% GDP)     ','       +' num2str(gdp75_D08to10_pct,'%.3f') '%    ','      ' num2str(gdp100_D10_pct,'%.3f') '%    ','      ' num2str(gdp125_D10_pct,'%.3f') '%   '])
disp(['D = 0.8->1.0 (bn €) ','       +' num2str(gdp75_D08to10_bnE,'%.1f') '      ','       +' num2str(gdp100_D08to10_bnE,'%.1f') '      ','      +' num2str(gdp125_D08to10_bnE,'%.1f') '      '])
disp(['D = 0.8->1.0 (% GDP)','       +' num2str(gdp75_D08to10_pct,'%.3f') '%    ','      +' num2str(gdp100_D08to10_pct,'%.3f') '%    ','      +' num2str(gdp125_D08to10_pct,'%.3f') '%   '])
disp(['Carb-tax rev (bn €) ','      ' num2str(taxrev75_bnE,'%.1f') '      ','      +' num2str(taxrev100_bnE_incr,'%.1f') '     ','       +' num2str(taxrev125_bnE_incr,'%.1f') '     '])
disp(['Carb-tax rev (% GDP)','       +' num2str(taxrev75_pct,'%.3f') '      ','     +' num2str(taxrev100_pct_incr,'%.3f') '%    ','      +' num2str(taxrev125_pct_incr,'%.3f') '%    '])
disp('----------------------------------------------------------------------')

disp(['GDP cost saved for tau=50, after 6 years: ' num2str((gdp125_D08_pct-gdp125_D10_pct)/gdp125_D08_pct*100,'%.1f'),'%'])
disp(' ')


%% Table 3 (effects for horizon of 3 years)
GDP = 13427; % EA GDP in 2022 in bn €
end_period = 13;
% 1) Effect higher carbon taxes on GDP (D=0.8)
gdp100_D08_pct = 100*(tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp100_D08_bnE = gdp100_D08_pct/100*GDP;
gdp125_D08_pct = 100*(tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp125_D08_bnE = gdp125_D08_pct/100*GDP;
% 2) Effect higher carbon taxes on GDP (D=1)
gdp100_D10_pct = 100*(tauShock25_DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp100_D10_bnE = gdp100_D10_pct/100*GDP;
gdp125_D10_pct = 100*(tauShock50_DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp125_D10_bnE = gdp125_D10_pct/100*GDP;
% 3) Differential effect higher carbon taxes on GDP (2)-1))
gdp75_D08to10_pct  = 100*(DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period)-SS_D(strcmp(M_.endo_names,'Y')))/SS_D(strcmp(M_.endo_names,'Y'));
gdp75_D08to10_bnE  = gdp75_D08to10_pct/100*GDP;
gdp100_D08to10_pct = gdp100_D10_pct - gdp100_D08_pct;
gdp100_D08to10_bnE = gdp100_D10_bnE - gdp100_D08_bnE;
gdp125_D08to10_pct = gdp125_D10_pct - gdp125_D08_pct;
gdp125_D08to10_bnE = gdp125_D10_bnE - gdp125_D08_bnE;
% 4) Effect higher carbon taxes on carbon tax revenue
% 100*tau*Z/Y gives impact on carbon tax revenue in percent
taxrev75_pct = 100*75*SS_D(strcmp(M_.endo_names,'Y'))*SS_D(strcmp(M_.endo_names,'Z'));
taxrev75_bnE = GDP*taxrev75_pct/100;
taxrev100_pct_incr = 100*100*tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Z(end_period)*tauShock25_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period) - taxrev75_pct;
taxrev100_bnE_incr = GDP*taxrev100_pct_incr/100;
taxrev125_pct_incr = 100*125*tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Z(end_period)*tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct.Y(end_period) - taxrev75_pct;
taxrev125_bnE_incr = GDP*taxrev125_pct_incr/100;


% Table 3 (horizon 3 years)
disp('       ---- TABLE 3 ----')
disp('----------------------------------------------------------------------')
disp(['Carbon Tax in €/ton ','        75       ','       100       ','       125       '])
disp('----------------------------------------------------------------------')
disp(['D = 0.8 (bn €)      ','       13,427    ','      ' num2str(gdp100_D08_bnE,'%.1f') '      ','       ' num2str(gdp125_D08_bnE,'%.1f') '      '])
disp(['D = 0.8 (% GDP)     ','       100%      ','       ' num2str(gdp100_D08_pct,'%.3f') '%   ','        ' num2str(gdp125_D08_pct,'%.3f') '%   '])
disp(['D = 1.0 (bn €)      ','       +' num2str(gdp75_D08to10_bnE,'%.1f') '      ','      ' num2str(gdp100_D10_bnE,'%.1f') '      ','       ' num2str(gdp125_D10_bnE,'%.1f') '      '])
disp(['D = 1.0 (% GDP)     ','       +' num2str(gdp75_D08to10_pct,'%.3f') '%    ','      ' num2str(gdp100_D10_pct,'%.3f') '%    ','       ' num2str(gdp125_D10_pct,'%.3f') '%   '])
disp(['D = 0.8->1.0 (bn €) ','       +' num2str(gdp75_D08to10_bnE,'%.1f') '      ','      +' num2str(gdp100_D08to10_bnE,'%.1f') '       ','      +' num2str(gdp125_D08to10_bnE,'%.1f') '      '])
disp(['D = 0.8->1.0 (% GDP)','       +' num2str(gdp75_D08to10_pct,'%.3f') '%    ','      +' num2str(gdp100_D08to10_pct,'%.3f') '%     ','      +' num2str(gdp125_D08to10_pct,'%.3f') '%   '])
disp(['Carb-tax rev (bn €) ','      ' num2str(taxrev75_bnE,'%.1f') '      ','      +' num2str(taxrev100_bnE_incr,'%.1f') '      ','       +' num2str(taxrev125_bnE_incr,'%.1f') '     '])
disp(['Carb-tax rev (% GDP)','       +' num2str(taxrev75_pct,'%.3f') '      ','     +' num2str(taxrev100_pct_incr,'%.3f') '%     ','      +' num2str(taxrev125_pct_incr,'%.3f') '%    '])
disp('----------------------------------------------------------------------')

disp(['GDP cost saved for tau=50, after 3 years: ' num2str((gdp125_D08_pct-gdp125_D10_pct)/gdp125_D08_pct*100,'%.1f'),'%'])
disp(' ')
disp('Scroll up in command window to see output for Table D.1.')


return

%% NPV of GDP costs saved after six years
GDP_EA_2022     = 3400;
Horizon         = 25; % after six years (period 1 <=> t=0)
IRFs_Tax_only   = tauShock50_SS_D08_tauSS75.IrfVectorsAsStruct;
IRFs_Tax_plus_D = tauShock50_DisclShock_SS_D08_tauSS75.IrfVectorsAsStruct;

CompoundInterestRate_Tax_only   = ones(25,1);
CompoundInterestRate_Tax_plus_D = ones(25,1);
for i=2:25
    CompoundInterestRate_Tax_only(i)    = CompoundInterestRate_Tax_only(i-1)   /IRFs_Tax_only.R(i);
    CompoundInterestRate_Tax_plus_D(i)  = CompoundInterestRate_Tax_plus_D(i-1) /IRFs_Tax_plus_D.R(i);
end
NPV_GDP_Tax_only        = sum(GDP_EA_2022*IRFs_Tax_only.Y(1:25) .* CompoundInterestRate_Tax_only);
NPV_GDP_Tax_Tax_plus_D  = sum(GDP_EA_2022*IRFs_Tax_plus_D.Y(1:25) .* CompoundInterestRate_Tax_plus_D);
NPV_GDP                 = NPV_GDP_Tax_Tax_plus_D-NPV_GDP_Tax_only;

