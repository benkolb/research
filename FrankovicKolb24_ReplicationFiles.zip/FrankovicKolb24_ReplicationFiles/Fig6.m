
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure 6: creates 4 separate figures with sensitivity analysis for one
% parameter each (subfig. a-d in Figure 6)


clear; close all force; clc;
addpath('tools');

tic

rob = {'epsY','epsE','epsF','zeta'};
Perform_RobustnessSim_Discl = 1;
Plot_RobustnessSim_Discl = 1;

for rr = 1:numel(rob)

    if strcmp(rob{rr},'epsY')
        RobustnessRuns.Rob_epsY_low  = { {'epsY', '0.4'} };
        RobustnessRuns.Rob_epsY_base = { {'epsY', '0.6'} };
        RobustnessRuns.Rob_epsY_high = { {'epsY', '0.8'} };
        fignam = 'Fig6a';
    elseif strcmp(rob{rr},'epsE')
        RobustnessRuns.Rob_epsE_low = { {'epsE', '1.5'} };
        RobustnessRuns.Rob_epsE_base= { {'epsE', '3'} };
        RobustnessRuns.Rob_epsE_high= { {'epsE', '5'} };
        fignam = 'Fig6b';
    elseif strcmp(rob{rr},'epsF')
        RobustnessRuns.Rob_epsF_low = { {'epsF', '0.075'} };
        RobustnessRuns.Rob_epsF_base= { {'epsF', '0.15'} };
        RobustnessRuns.Rob_epsF_high ={ {'epsF', '0.29'} };
        fignam = 'Fig6c';
    elseif strcmp(rob{rr},'zeta')
        % "zeta" parameter (for legacy reasons called "UnDiscloZ_L" here):
        RobustnessRuns.Rob_UndZ_low  = { {'UnDisclZ_L', '0'},{'UnDisclZ_Y', '1'} };
        RobustnessRuns.Rob_UndZ_base = { {'UnDisclZ_L', '0.05*0.20'},{'UnDisclZ_Y', '1-0.05*0.20'} };
        RobustnessRuns.Rob_UndZ_high = { {'UnDisclZ_L', '1'},{'UnDisclZ_Y', '0'} };
        fignam = 'Fig6d';
    end



    RobustnessRunNames = fieldnames(RobustnessRuns);

    % Disclosure Runs
    for Ni = 1:length(RobustnessRunNames)



        % Get new steady state with lower D
        SimName                         = strcat('SS_sim_D08_',RobustnessRunNames{Ni})
        [SS,Parameters,DynareMacroVars] = prepareSimulation;

        %change Param
        Robustness_Run_Specification = RobustnessRuns.(RobustnessRunNames{Ni});
        for i=1:length(Robustness_Run_Specification)
            SetParamStatement = strcat('Parameters.',Robustness_Run_Specification{i}{1},'=',num2str(Robustness_Run_Specification{i}{2}),';')
            eval(SetParamStatement)
        end
        DynareMacroVars.recalculateSS = 1;

        DynareMacroVars.TauShock        = 'Off';
        DynareMacroVars.DisclosureShock = 'On';
        DisclosurePath  = (1-0.8)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
        DisclosureEnd   = DisclosurePath(end);  save('Shocks/DisclosureEnd.mat','DisclosureEnd')
        RunModel
        IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
        format long
        SS_D          = Simulation.IrfVectors(:,end);


        % D shock from lower initial D steady state to 100%
        SimName = strcat('DisclShock_SS_D08_',RobustnessRunNames{Ni})
        % take over parameters from above
        Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
        Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
        Parameters.D_SS     = IRFS_D_SS_run.D(end);
        Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
        Manual_SS           = SS_D;
        DynareMacroVars.recalculateSS = 0;
        DynareMacroVars.TauShock        = 'Off';
        DynareMacroVars.DisclosureShock = 'On';
        D_Shock = -(1-0.8);
        DisclosurePath  = [linspace(D_Shock,D_Shock,120)];  save('Shocks/DisclosurePath.mat','DisclosurePath')
        DisclosureEnd   = DisclosurePath(end);              save('Shocks/DisclosureEnd.mat','DisclosureEnd')
        RunModel

    end

    clear RobustnessRuns

    %% plot responses
    nh = 24;                        % # quarters plotted
    colour = [0, 98, 161]/255;      % define color of irfs
    colour2 = [0.850 0.325 0.098];  % define second color of irfs

    xtick_years = (0:6)*4;
    vtit = {...
        {'Fossil spread'; '$E_t \{ R^F_{t+1}-R_t \}$'},...
        {'Low-carbon investm.'; '$I^L_t$'},...
        {'GDP'; '$Y_t$'},...
        {'Bank capital ratio'; '$Q_tK_t/N_t$'},...
        {'Emissions'; '$Z_t$'},...
        };
    vlab = {...
        'ann. bps fr. SS',...
        '\% from SS',...
        '\% from SS',...
        'PP from SS'...
        '\% from SS',...
        };
    ytik = {{0:15:45},...
        {0:1:4},...
        {0:0.02:0.08},...
        {-0.1:0.1:0.35},...
        {-0.2:0.05:0.05},...
        };
    XX1 = load(['simulations/DisclShock_SS_D08_',RobustnessRunNames{1}]);
    XX2 = load(['simulations/DisclShock_SS_D08_',RobustnessRunNames{2}]);
    XX3 = load(['simulations/DisclShock_SS_D08_',RobustnessRunNames{3}]);
    vnam = {'SPRF','IL','Y','Kappa','Z'};
    vadj = {'spr','ptc','ptc','100','ptc'};
    irfs1 = nan(nh,numel(vnam));
    irfs2 = irfs1;
    irfs3 = irfs1;
    for vv = 1:numel(vnam)
        x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
        x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
        x3 = XX3.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
        if strcmp(vadj{vv},'ptc')
            x1  = 100.*(x1-x1(1))./x1(1);
            x2  = 100.*(x2-x2(1))./x2(1);
            x3  = 100.*(x3-x3(1))./x3(1);
        elseif strcmp(vadj{vv},'100')
            x1 = 100.*(x1-x1(1));
            x2 = 100.*(x2-x2(1));
            x3 = 100.*(x3-x3(1));
        elseif strcmp(vadj{vv},'spr')
            x1 = 400*100.*(x1+XX1.IrfVectors(strcmp(XX1.M_.endo_names,'R'),1:nh)'-x1(1)-XX1.IrfVectors(strcmp(XX1.M_.endo_names,'R'),1))./(x1(1)+XX1.IrfVectors(strcmp(XX1.M_.endo_names,'R'),1));
            x2 = 400*100.*(x2+XX2.IrfVectors(strcmp(XX2.M_.endo_names,'R'),1:nh)'-x2(1)-XX2.IrfVectors(strcmp(XX2.M_.endo_names,'R'),1))./(x2(1)+XX2.IrfVectors(strcmp(XX2.M_.endo_names,'R'),1));
            x3 = 400*100.*(x3+XX3.IrfVectors(strcmp(XX3.M_.endo_names,'R'),1:nh)'-x3(1)-XX3.IrfVectors(strcmp(XX3.M_.endo_names,'R'),1))./(x3(1)+XX3.IrfVectors(strcmp(XX3.M_.endo_names,'R'),1));
        end
        irfs1(:,vv) = x1;
        irfs2(:,vv) = x2;
        irfs3(:,vv) = x3;
    end

    t = 1:nh;
    cmap = colororder;
    figure('name','Robustness')
    nv = numel(vtit);
    for vv = 1:nv
        subplot(5,5,vv)
        plot(t,irfs2(:,vv),'Color',colour,'LineWidth',1.5); hold on; % baseline
        plot(t,irfs1(:,vv),'Color',colour2,'LineWidth',1.5,'LineStyle','--'); hold on;
        plot(t,irfs3(:,vv),'Color',cmap(3,:),'LineWidth',1.5,'LineStyle',':'); hold on;
        plot(t,zeros(nh,1),'k--')
        xticks([8 16 24]);
        xticklabels([2 4 6])
        xtickangle(0)
        title(vtit{vv},'interpreter','latex','Fontsize',6);
        ylabel(vlab{vv},'interpreter','latex','FontSize',6);
        xlabel('years','interpreter','latex','FontSize',6);
        ylim([min(cell2mat(ytik{vv})) max(cell2mat(ytik{vv}))])
        yticks(cell2mat(ytik{vv}))
        xlim([1 24])
        a = get(gca,'XTickLabel');
        set(gca,'XTickLabel',a,'fontsize',6)
        a = get(gca,'YTickLabel');
        set(gca,'YTickLabel',a,'fontsize',6)
    end
    saveas(gcf,['figures/' fignam '.pdf']);

end


toc


return
% Disclosure Plots
PlotSim({strcat('DisclShock_SS_D08_',RobustnessRunNames{1}),strcat('DisclShock_SS_D08_',RobustnessRunNames{2}),strcat('DisclShock_SS_D08_',RobustnessRunNames{3})}, ...
    'Periods',25,...
    'ToPlot', ...
    {'100*100*ann(R+SPRF)','ptc(IL)','ptc(Y)','100*Kappa','ptc(FF)'},...
    'Plot_Titles', ...
    {'Fossil spread (ann., bp)', 'Low-carbon inv. (%)','GDP (%)', 'Risk-adj. capital ratio (pp)','Emissions (%)'}, 'xAxis','y',...
    'Legend', Legend,'ShowLegend',0,'LineStyle',{'--','-',':'},'NoSteadyStateLine',1,...
    'Plots_Horizontally',5,'Plots_Vertically',1,'fullscreen',6,... BK: from 'Plots_Horizontally',5,'Plots_Vertically',1,'fullscreen',6,
    'TextFontSize',15)
saveas(gcf,strcat('Figures/Disclosure_Shock_',RobustnessRunNames{1}(1:8),'.png'))
% BKnew:
fontname(gcf,'Helvetica')
exportgraphics(gcf,['Figures_bk/Disclosure_Shock_',RobustnessRunNames{1}(1:8),'.pdf'])



