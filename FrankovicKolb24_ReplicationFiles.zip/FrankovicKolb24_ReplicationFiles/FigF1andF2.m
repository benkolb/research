
% Replication code for Frankovic/Kolb (2024) "The Role of Emission
% Disclosure for the Green Transition".
% March 2024
% Figure F.1 and F.2: Subsidy vs carbon-tax shock

clear; close all force; clc;
addpath('tools');

tic


tau_SS = 75;
tau_SS_text = num2str(tau_SS);

initial_D = 0.8;
D_text = num2str(initial_D);
D_text = D_text([1,3]); %remove dots


% Get new steady state with lower D  
SimName                         = ['SS_sim_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = (1-initial_D)*ones(1,120);  save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);      save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel
%PlotSim({'SS_sim_D08'}, 'Periods',202,'ToPlot',{'eI_F_tilde','100*Kappa','ptc(Y)','ptc(N)','ptc(IF)','ptc(IL)','100*SPRF','D'})
IRFS_D_SS_run = Simulation.IrfVectorsAsStruct;
format long
SS_D          = Simulation.IrfVectors(:,end);


% tau shock from lower initial D steady state
SimName = ['tauShock_SS_D',D_text,'_tauSS',tau_SS_text]; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
CarbonPricePath = 50*ones(1,120);       save('Shocks/CarbonPricePath.mat','CarbonPricePath')
CarbonPriceEnd  = CarbonPricePath(end); save('Shocks/CarbonPriceEnd.mat','CarbonPriceEnd')
RunModel 


% tau shock from lower initial D steady state
SimName = ['subShock_SS_D',D_text,'_tauSS',tau_SS_text]; 
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.SubsELShock     = 'On';
SubsEL_Path  = 0.40*ones(1,120);  save('Shocks/SubsEL_Path.mat','SubsEL_Path')
SubsEL_End   = SubsEL_Path(end); save('Shocks/SubsEL_End.mat','SubsEL_End')
RunModel 


% tau and D  shock from lower initial D steady state to 1
SimName = ['subShock_DisclShock_SS_D',D_text,'_tauSS',tau_SS_text];
[SS,Parameters,DynareMacroVars] = prepareSimulation;
Parameters.tau_SS = tau_SS;
Parameters.P_FSS    = IRFS_D_SS_run.P_F(end);
Parameters.KappaSS  = IRFS_D_SS_run.Kappa(end);
Parameters.D_SS     = IRFS_D_SS_run.D(end);
Parameters.rho_SS   = IRFS_D_SS_run.rho(end);
Manual_SS           = SS_D;
DynareMacroVars.recalculateSS = 0; 
DynareMacroVars.TauShock        = 'Off';
DynareMacroVars.SubsELShock     = 'On';
SubsEL_Path  = 0.40*ones(1,120);  save('Shocks/SubsEL_Path.mat','SubsEL_Path')
SubsEL_End   = SubsEL_Path(end); save('Shocks/SubsEL_End.mat','SubsEL_End')
DynareMacroVars.DisclosureShock = 'On';
DisclosurePath  = [linspace(-0.2,-0.2,120)];    save('Shocks/DisclosurePath.mat','DisclosurePath')
DisclosureEnd   = DisclosurePath(end);          save('Shocks/DisclosureEnd.mat','DisclosureEnd')
RunModel 



%% plot responses
nh = 80;                        % # quarters plotted
%prctls = [50 16 84 5 95 5 95];% [50 16 84 5 95 2.5 97.5];       % percentiles of draws that are plotted
colour = [0, 98, 161]/255;      % define color of irfs
colour2 = [0.850 0.325 0.098];  % define second color of irfs

xtick_years = (0:20)*4;
vtit = {...
    'Emissions $Z_t$',...
    'Low-carbon ($L$) investment $I^L_t$',...
    'Fossil investment $I^F_t$',...
    '$L$ energy price $P^{EL}_t$', ...
    '$L$ energy output $E^L_t$', ...
    '$L$ capital asset price $Q^L_t$',...
    'GDP $Y_t$',...
    'Consumption $C_t$',...
    'Bank capital ratio $Q_tK_t/N_t$'...
    };
vlab = {...
    '\% from SS','\% from SS','\% from SS',...
    '\% from SS','\% from SS','\% from SS',...
    '\% from SS','\% from SS','PP from SS'...
    };
vnam = {'Z','IL','IF',...
    'P_EL','EL','QkL',...
    'Y','C','Kappa'};
vadj = {'ptc','ptc','ptc',...
    'ptc','ptc','ptc',...
    'ptc','ptc','100'};
ytik = {{-40:10:10},...
    {0:100:500},...
    {-80:20:0},...
    {0:15:75},...
    {0:50:250},...
    {0:10:40},...
    {-1:1:3},...
    {-2:0.5:0.5},...
    {-2:2:8},...
    };

% Figure 9
XX1 = load('simulations/subShock_SS_D08_tauSS75.mat');
XX2 = load('simulations/tauShock_SS_D08_tauSS75.mat');
irfs1 = nan(nh,numel(vnam));
irfs2 = irfs1;
for vv = 1:numel(vnam)
    x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
    x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
    if strcmp(vadj{vv},'ptc')
        x1  = 100.*(x1-x1(1))./x1(1);
        x2  = 100.*(x2-x2(1))./x2(1);
    elseif strcmp(vadj{vv},'100')
        x1 = 100.*(x1-x1(1));
        x2 = 100.*(x2-x2(1));
    end
    irfs1(:,vv) = x1;
    irfs2(:,vv) = x2;
end

t = 1:nh;
figure('name','subsidy vs. carbon-tax shock')
nv = numel(vtit);
for vv = 1:nv
    subplot(3,3,vv)
    plot(t,irfs1(:,vv),'Color',colour2,'LineWidth',2); hold on;
    plot(t,irfs2(:,vv),'Color',colour,'LineWidth',2,'LineStyle','--'); hold on;
    plot(t,zeros(nh,1),'k--')
    xticks([0 20 40 60 80]);
    xticklabels(xtick_years/4*5)
    xtickangle(0)
    title(vtit{vv},'interpreter','latex');
    ylabel(vlab{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 9; legend('subsidy','carbon tax','interpreter','latex','Location','NorthEast','Box','off'); end
    ylim([min(cell2mat(ytik{vv})) max(cell2mat(ytik{vv}))])
    yticks(cell2mat(ytik{vv}))
    xlim([1 80])
end
saveas(gcf,'figures/FigF1.pdf');


% Figure 10
XX1 = load('simulations/subShock_SS_D08_tauSS75.mat');
XX2 = load('simulations/subShock_DisclShock_SS_D08_tauSS75.mat');
irfs1 = nan(nh,numel(vnam));
irfs2 = irfs1;
for vv = 1:numel(vnam)
    x1 = XX1.IrfVectors(strcmp(XX1.M_.endo_names,vnam{vv}),1:nh)';
    x2 = XX2.IrfVectors(strcmp(XX2.M_.endo_names,vnam{vv}),1:nh)';
    if strcmp(vadj{vv},'ptc')
        x1  = 100.*(x1-x1(1))./x1(1);
        x2  = 100.*(x2-x2(1))./x2(1);
    elseif strcmp(vadj{vv},'100')
        x1 = 100.*(x1-x1(1));
        x2 = 100.*(x2-x2(1));
    end
    irfs1(:,vv) = x1;
    irfs2(:,vv) = x2;
end

t = 1:nh;
figure('name','Subsidy with and without D shock')
nv = numel(vtit);
for vv = 1:nv
    subplot(3,3,vv)
    plot(t,irfs1(:,vv),'Color',colour2,'LineWidth',2); hold on;
    plot(t,irfs2(:,vv),'Color',colour,'LineWidth',2,'LineStyle','--'); hold on;
    plot(t,zeros(nh,1),'k--')
    xticks([0 20 40 60 80]);
    xticklabels(xtick_years/4*5)
    xtickangle(0)
    title(vtit{vv},'interpreter','latex');
    ylabel(vlab{vv},'interpreter','latex');
    xlabel('years','interpreter','latex');
    if vv == 9; legend('$D=0.8$','$D=1$','interpreter','latex','Location','NorthEast','Box','off'); end
    ylim([min(cell2mat(ytik{vv})) max(cell2mat(ytik{vv}))])
    yticks(cell2mat(ytik{vv}))
    xlim([1 80])
end
saveas(gcf,'figures/FigF2.pdf');


