function VarList = loadEndVar

    VarList = {
    'Y', 		% output
    'K', 		% capital
    'L', 		% labour supply
    'I', 		% investment
    'C', 		% household consumption
    'G', 		% government spending
    'Qk', 		% price of capital
    'LAM',      % stochastic discount factor
    'M',		% growth rate of stoch. discount factor
    'RY', 		% return on capital	
    'R', 		% return on safe bond	
    'Rn',       % nominal return on safe bond
    'Pi',       % inflation
    'AC',       % price adjustment cost
    'DAC',      % derivative of price adjustment cost
    'N', 		% total bank net worth
    'Ne', 		% net worth of existing banks
    'Nn', 		% net worth of entering banks
    'epsI',     % elasticity of subst. across interm. goods
    'MC', 		% marginal cost
    'W',        % wage rate
    'ACI',      % Adjustment cost on investment
    'EXA',      % technology (TFP) shock
    'EXAL',     % technology (TFP) shock
    'EXAF',     % technology (TFP) shock
    'EXK',      % capital efficiency shock
    'EXKL',     % capital efficiency in the low carbon sector shock
    'EXKF',     % capital efficiency in the fossil sector shock
    'EXG',      % government spending shock
    'EXC',      % consumption preference shock
    'CD',       % Capital-Labor input
    'KL',       % capital in the low-carbon sector
    'KF',       % capital in the fossil sector
    'RL',      % return on capital	in the low-carbon sector
    'RF',      % return on capital	n the fossil sector
    'IL',		% investment in the low-carbon sector
    'IF', 		% investment in the fossil sector
    'I_total',  % Total investment
    'QkL',		% price of capital in the low-carbon sector
    'QkF',		% price of capital in the fossil sector
    'Qk_avg',   % average equity price
    'E',        % energy input
    'EL',       % energy input from the low-carbon sector
    'EF',       % energy input from the fossil sector
    'P_E',      % price of energy input
    'P_EL',     % price of energy input from the low-carbon sector
    'P_EF',     % price of energy input from the fossil sector
    'FF',       % fossil ressource use in the fossil sector
    'P_F',      % price of fossil fuels
    'tau',      % Tax on fossil fuels
    'NU',       % Shadow value of bank net worth
    'SPR',      % Spread 
    'SPRL',     % Spread low-carbon
    'SPRF',     % Spread fossil
    'Kappa',    % Ratio Net worth to risk-weighted assets
    's',        % Share of intermediaries' portfolio in Y sector
    'sL',       % Share of intermediaries' portfolio in L sector
    'sF',       % Share of intermediaries' portfolio in F sector
    'OME',
    'TR',
    'rho',      % absconding rate,
    'rhoF',     % relativ risk factor for fossil sector
    'rhoL',     % relativ risk factor for low-carbon sector
    'SP',       % Stock portfolio value of financial intermediaries
    'D',        % Degree of disclosure
    'ExpSpread_Y',
    'ExpSpread_L',
    'ExpSpread_F',
    'FF_tilde',
    'EF_tilde',
    'P_EF_tilde',
    'eI_F_tilde',
    'Z',            %total emissions
    'RWA',      % Risk-weighted assets
    'ResidHHBudget',
    'B',
    'Delta_V_D',
    'rhoF_Adj',
    'Unaccounted_Z',
    'Delta_RF_D',
    'Delta_RL_D',
    'Delta_RY_D',
    'lambda_I',
    'w_EL',
    's_EL', %subsidy to EL
    'lambda_F', %shadow price of fossil fuel use w.r.t emission constraint
    };



    %% write a modfile
    fileID = fopen('tools/Include_EndVars.mod','w');

    for ii = 1:length(VarList)
      varname = num2str(cell2mat(VarList(ii)));
      fprintf(fileID,varname+"\n");
    end
    fclose(fileID);

end