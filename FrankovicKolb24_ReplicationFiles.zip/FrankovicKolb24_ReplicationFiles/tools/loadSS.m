function [ss,Parameter] = model_ss(Parameter,VarList,showTable)

% Load Parameters
pnames = fieldnames(Parameter);
for j = 1:length(pnames)
    pname = deblank(pnames{j});
    eval([pname,' = Parameter.(pname);'])
end


options=optimset('Display','off','MaxIter', 5000, 'MaxFunEvals', 1e10, 'TolFun', 1e-16);


%% Enter model equations here

Qk      = 1;
QkL     = 1;
QkF     = 1;
Qk_avg  = 1;
M       = bet*1;
D       = D_SS;

EXA     = 1;
EXAL    = 1;
EXAF    = 1;
EXK     = 1;
EXG     = 1;
EXKL    = 1;
EXKF    = 1;
EXC     = 1;

AC      = 0;
DAC     = 0;
ACI     = 0;

Pi      = pi_SS;
R       = 1/bet;
Rn      = R*Pi;
epsI    = epsI_ss;
MC      = (epsI-1)/epsI;
RY      = R+SPRSS;
RF      = R+SPRFSS;
RL      = R+SPRLSS;

tau     = tau_SS;
w_EL    = w_EL_SS; 
s_EL    = 0; %subsidy to EL



P_E     = (EnCost_Share_YCost*MC^(1-epsY)/(1-w_CD))^(1/(1-epsY));     %follows from calibration target and FOC on E
P_EL    = P_E; 
aL      = (RL-1+delL)/P_EL; %set aL such that price is correct

aY      = 1;
Y       = 1;
CD      = ( LabInc_Share/( (1-alf) * (Y)^(1/epsY-1) * w_CD^(1/epsY) ) )^(epsY/(epsY-1)); %FOC Labor + calibration target
K       = MC*(Y^(1/epsY))*w_CD^(1/epsY)*CD^((epsY-1)/epsY)*alf / ((RY)-1+del) ; %Return on capital
L       = (CD/(K^alf))^(1/(1-alf)); %CD Prod function
W       = MC*(Y^(1/epsY))*w_CD^(1/epsY)*CD^((epsY-1)/epsY)*(1-alf) / L; %FOC Labor

E       = ( (Y^((epsY-1)/epsY) - w_CD^(1/epsY) * CD^((epsY-1)/epsY)) / ((1-w_CD)^(1/epsY)) )^(epsY/(epsY-1)); %Y prod function
EL      = w_EL * (P_EL/P_E)^(-epsE) * E; %FOC EL
KL      = EL/aL; %CD Prod EL




P_EF    = ((((P_E)^(1-epsE) - w_EL*(P_EL)^(1-epsE))/(1-w_EL))^(1/(1-epsE))); %Pricing equation P_E
EF      = ((1-Share_L_in_E)*(P_E)*(E) 	/(P_EF) );  %expenditure target


Z           = EmissionCost_1EuroCarbonPrice * Y;
eI_F_FF     = @(FF) Z/FF; %EmissionCost_1EuroCarbonPrice / (FF/Y);
% with this eI_F*FF/Y equals exactly the emission cost
% that 1 Euro would cause in the initial ss. Hence, tau has the unit
% Euro/tonne CO2-equivalent
P_F_FF      = @(FF) (FF/EF * 1/(1-w_KF))^(1/-epsF) * P_EF - eI_F_FF(FF)*tau;
Find        = @(FF) Fossil_Share_Y*Y - (tau*eI_F_FF(FF) + P_F_FF(FF) ) * FF;
FF          = fsolve(Find,0.1,options);
eI_F        = eI_F_FF(FF);
P_F         = P_F_FF(FF);
P_FSS       = P_F;
% F_PF    = @(P_F) Fossil_Share_Y/(P_F)*Y;
% tcv_PF  = @(P_F) EmissionCost_1EuroCarbonPrice / (F_PF(P_F)/Y);
% Find    = @(P_F) F_PF(P_F) - (1-w_KF) * ((P_F+tau*tcv_PF(P_F))/P_EF)^(-epsF) * EF;
% P_F     = fsolve(Find,1,options);
% P_FSS   = P_F;
% FF      = F_PF(P_F);
% eI_F    = tcv_PF(P_F); 
eI_F_tilde = D*eI_F;
lambda_F = 0;




aF_KF   = @(KF) (( EF^((epsF-1)/epsF) - (1-w_KF)^(1/epsF) * FF^((epsF-1)/epsF) ) / (w_KF^(1/epsF)) )^(epsF/(epsF-1)) / KF;
Find    = @(KF) RF - (1-delF + P_EF*EF^(1/epsF)*w_KF^(1/epsF)*(aF_KF(KF)*KF)^((epsF-1)/epsF)/KF  );
KF      = fsolve(Find,1,options);
aF      = aF_KF(KF);


Z_unaccounted = 0;



SP   = Qk*K + QkL*KL + QkF*KF;

s   = (Qk)*(K)/(SP);    s_SS = s;
sL  = (QkL)*(KL)/(SP);  sL_SS = sL;
sF  = (QkF)*(KF)/(SP);  sF_SS = sF;
TR = (RY-R)*s  + (RL-R)*sL + (RF-R)*sF;

IL = (delL*(KL));
IF = (delF*(KF));
I   = (del*(K));
I_total = I + IL + IF;

ISS     = (I);
ILSS    = (IL);
IFSS    = (IF);

G   = G_Share_Y*Y;

C   = ((Y)-(I)-(IL)-(IF)-(G));
LAM = ((1-bet*hab)*((1-hab)*(C))^(-sig));







if RY == R

    rho = 1; rho_SS = rho;
    rhoF = 1; rhoF_SS = rhoF;
    rhoL = 1; rhoL_SS = rhoL;
    RWA = Qk*K + rhoL*QkL*KL + rhoF*QkF*KF;
    Kappa = KappaSS;
    N = Kappa*RWA;

    Ne  = ( tet*( ((RY)-(R))*(Qk)*(K) + ((RL)-(R))*(QkL)*(KL) + ((RF)-(R))*(QkF)*(KF) + (R)*(N) ) );    
    Nn  = N-Ne;
    omg = Nn/(  (Qk)*(EXK)*(K) + (QkL)*(EXKL)*(KL) + (QkF)*(EXKF)*(KF)  );

    OME = M*(1-tet)/(1-M*tet*R);
    NU = OME*R;
    SPR = 0; SPRL = 0; SPRF = 0; ExpSpr = 0;

    
    ExpSpread_L = 0;  
    ExpSpread_F = 0;  
    ExpSpread_Y = 0;
else
    rhoF = SPRFSS / SPRSS; rhoF_SS = rhoF;
    rhoL = SPRLSS / SPRSS; rhoL_SS = rhoL;
    RWA = Qk*K + rhoL*QkL*KL + rhoF*QkF*KF;
    Kappa = KappaSS;
    N = Kappa*RWA;
    
    Ne  = tet*( (RY-R)*Qk*K + (RL-R)*QkL*KL + (RF-R)*QkF*KF + R*N );    
    Nn  = N-Ne;
    omg = Nn/(  (Qk)*(EXK)*(K) + (QkL)*(EXKL)*(KL) + (QkF)*(EXKF)*(KF)  );
    
    OME_PHI = @(NU) M*(1-tet+tet*NU);
    rho_PHI = @(NU) NU*OME_PHI(NU)*TR/(s+rhoL*sL+rhoF*sF) / (NU - R*OME_PHI(NU));
    Find    = @(NU) rho_PHI(NU)*RWA - (NU)*(N); 
    NU  = fsolve(Find,4,options);
    SPR = RY-R;
    SPRL = RL-R;
    SPRF = RF-R; 
    rho = rho_PHI(NU); rho_SS = rho;
    OME = OME_PHI(NU);
    ExpSpread_L = rhoL* (RY-R);  
    ExpSpread_F = rhoF* (RY-R);  
    ExpSpread_Y = (rho - OME*rho*R/ NU ) / OME;
end



FF_tilde    = FF;
EF_tilde    = EF;
P_EF_tilde  = P_EF;
Delta_RF_D      = ( EXKF*(QkF-delF)*KF + P_EF_tilde*EF_tilde - FF_tilde*P_F - tau*eI_F_tilde*FF_tilde  )/(KF*QkF) - RF;
Unaccounted_Z   = eI_F*FF-eI_F_tilde*FF_tilde;
Delta_RL_D      = (EXKL*(QkL-delL)*KL + P_EL*EL - 1*tau*Unaccounted_Z )/(KL*QkL) - RL;
Delta_RY_D      = ( EXK*(Qk-del )*K + MC*Y-W*L-P_E*E - 0*tau*Unaccounted_Z )/(K*Qk) - RY;

Delta_V_D       = OME * (Delta_RY_D * (Qk*K) + Delta_RL_D * (QkL*KL) + Delta_RF_D * (QkF*KF));
rhoF_Adj        = OME * Delta_RF_D / rho;
lambda_I        = OME*TR/(rho*(s+rhoL*sL+rhoF*sF));



chi     = LAM*W/(L^fri); %Parameter
GSS     = G; %Parameter
RnSS    = Rn;


P_EF_SS = P_EF;
EF_SS   = EF;
P_EL_SS = P_EL;
EL_SS   = EL;
L_SS    = L;

NUSS    = NU;



%% balance check
B = Qk*K + QkL*KL + QkF*KF - N;

Prof_Res    = FF*P_F;
Prof_Q      = 0;
Prof_Y      = (1-MC)*Y;
Prof_Bank   = Ne/tet*(1-tet);



ResidHHBudget = W*L - G + eI_F*FF*tau + (R-1)*B - C + Prof_Res + Prof_Q + Prof_Y + Prof_Bank - Nn;





%% Steady state properties




if showTable
    
    Moment = ["C/Y"; "I/Y"; "IL/Y"; "IF/Y"; "G/Y";...
              "P_E*E/Y"; "W*L/(MC*Y)"; "K*(RY-1+del)/(MC*Y)";...
              "EL*P_EL/(P_E*E)"; "EF*P_EF/(P_E*E)"; "P_F*FF/Y"];
    ValueinPercent = [C/Y;I/Y;IL/Y;IF/Y;G/Y;...
            P_E*E/Y;W*L/(MC*Y);K*(RY-1+del)/(MC*Y);...
            EL*P_EL/(P_E*E);EF*P_EF/(P_E*E);P_F*FF/Y] * 100;
    Target = [0;0;0;0;G_Share_Y;...
            EnCost_Share_Y;LabInc_Share;CapInc_Share;...
            Share_L_in_E;1-Share_L_in_E;Fossil_Share_Y] * 100;
    
    SSTable = table(Moment,ValueinPercent,Target);
    SSTable

end

%% some of the Steady-State paramters are set in this file,
% to capture these changes all parameters are set to the value defined
% in this file
pnames = fieldnames(Parameter);
for j = 1:length(pnames)
    pname = deblank(pnames{j});
    eval(['Parameter.' pname ' = ' pname ';'])
end


%% write a modfile


ss = zeros(length(VarList),1);
for ii = 1:length(VarList)
  varname = num2str(cell2mat(VarList(ii)));
  eval(['ss(' int2str(ii) ') = ' varname ';']);
end

fileID = fopen('tools/SS_values.mod','w');
for ii = 1:length(VarList)
  varname = num2str(cell2mat(VarList(ii)));
  fprintf(fileID,varname+"=%.25f ;\n",ss(ii));
end
fclose(fileID);

end
