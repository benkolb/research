

% recalculate SS
if DynareMacroVars.recalculateSS 
    VarList         = loadEndVars;
    [SS,Parameters] = loadSS(Parameters,VarList,1);
else
    VarList         = loadEndVars;

    fileID = fopen('tools/SS_values.mod','w');
    for ii = 1:length(VarList)
      varname = num2str(cell2mat(VarList(ii)));
      fprintf(fileID,varname+"=%.25f ;\n",Manual_SS(ii));
    end
    fclose(fileID);
end

% Provide parameters to Dynare
save('tools/Param.mat','-struct','Parameters');




%% execute Dynare with MacroVars

CommandText = 'dynare model_no_homotopy ';

Fields = fields(DynareMacroVars);
for i = 1:numel(Fields)
    if isnumeric(DynareMacroVars.(Fields{i}))
        CommandText = strcat(CommandText, ' -D',Fields{i},'=', num2str(DynareMacroVars.(Fields{i})));
    else
        CommandText = strcat(CommandText, ' -D',Fields{i},'="', DynareMacroVars.(Fields{i}), '"' );
    end
end
CommandText = char(strcat(CommandText,';'))
eval(CommandText);










%% Save Run

% create folder plots if it does not exist
if ~exist('simulations', 'dir') 
    mkdir('simulations'); 
end

% Save results and specs in a mat file with the name SimName
IRFs = struct();
for i=1:M_.endo_nbr
    eval([ 'IRFs.' char(M_.endo_names(i,:)) ' = ' char(M_.endo_names(i,:)) ';'])
end

if DynareMacroVars.SolvingType(1)=='d'
    Simulation = struct();
    Simulation.IrfVectors = oo_.endo_simul;
    Simulation.IrfVectorsAsStruct = IRFs;
    Simulation.Timestamp = datetime;
    Simulation.dynare_version = oo_.dynare_version;
    Simulation.matlab_version = ver;
    Simulation.M_ = M_;    
    Simulation.SimType = 'd';
    save(strcat('simulations/',SimName),'-struct','Simulation');
elseif DynareMacroVars.SolvingType(1)=='s'
    Simulation = struct();
    Simulation.IrfVectors = oo_.steady_state + cell2mat(struct2cell(oo_.irfs));
    Simulation.SS = oo_.steady_state;
    %Simulation.IrfVectorsAsStruct = IRFs;
    Simulation.Timestamp = datetime;
    Simulation.dynare_version = oo_.dynare_version;
    Simulation.matlab_version = ver;
    Simulation.M_ = M_; 
    Simulation.oo_ = oo_;
    Simulation.SimType = 's';
    save(strcat('simulations/',SimName),'-struct','Simulation');
end





%% Delete all superfluos DynareFiles
DeleteDynareFiles = 1;
if DeleteDynareFiles
    w = warning ('off','all');               
    delete *.eps;
    delete *.asv;
    delete model.log model.m model_dynamic.m model_dynamic.bin model_dynamic.cod model_static.m model_results.mat model_set_auxiliary_variables.m model_static.bin model_static.cod;
    delete ParamDynare.mat ssDynare.mat Param.mat Shocks.mat;
    %rmdir(SimProp.Options.modFileName, 's') % removing model folder 
    if exist('model', 'dir') 
        rmdir('model', 's') % removing model folder 
    end
    if exist('+model', 'dir') 
        rmdir('+model', 's') % removing model folder 
    end
    w = warning ('on','all');
end

                                      
                                                   
