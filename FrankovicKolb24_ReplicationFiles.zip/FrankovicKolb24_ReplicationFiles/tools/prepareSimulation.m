function [SS,Parameters,DynareMacroVars] = prepareSimulation

    VarList         = loadEndVars;
    Parameters      = loadParameters;
    [SS,Parameters] = loadSS(Parameters,VarList,0);
    % Provide parameters to Dynare
    save('tools/Param.mat','-struct','Parameters');

    DynareMacroVars                     = struct();

    DynareMacroVars.recalculateSS               = 1;
    DynareMacroVars.SolvingType                 = 'deterministic';
    DynareMacroVars.FinFric                     = 'On';
    DynareMacroVars.StockSharesFixed            = 'Off';
    DynareMacroVars.solve_algo                  = '10';
    DynareMacroVars.EndLabSupply                = 'On';
    DynareMacroVars.ExoVarShocked               = 'On';
    DynareMacroVars.TauShock                    = 'On';
    DynareMacroVars.DisclosureShock             = 'Off';   
    DynareMacroVars.AddUnanticipatedShock       = 'Off';
    DynareMacroVars.AddUnanticipated_tauShock   = 'Off';
    DynareMacroVars.TechShock                   = 'Off';
    DynareMacroVars.FossilPriceShock            = 'Off';
    DynareMacroVars.rhoShock                    = 'Off';
    DynareMacroVars.rhoLShock                   = 'Off';
    DynareMacroVars.rhoFShock                   = 'Off';
    DynareMacroVars.KapQualShock                = 'Off';
    DynareMacroVars.KapQualFShock               = 'Off'; 
    DynareMacroVars.WeightELShock               = 'Off'; 
    DynareMacroVars.SubsELShock                 = 'Off';
    DynareMacroVars.EmissionConstraint          = 'Off';
    DynareMacroVars.LongHorizon                 = 'Off'; %more periods, more homotopy steps, longer horizon

end