function PlotSim(Simulations,varargin)
% Syntax:
%
% PlotSimulationResults(Simulations,OtherOptionalInputs)
% e.g. PlotSimulationResults({'SimulationExample'});
%
% Description:
%
% The function PlotSimulationResults plots the Impulse Response Functions
% (IRFS) of saved simulations
%
% Input:
%
% - Simulations:        MANDATORY: Names of simulations (in the 'simulations' folder) for
%                       which multiplier will be calculated. Provide in a
%                       list as in {'Run1','Run2'} (up to ten simulations
%                       are possible)
%
% ALL OTHER INPUTS ARE OPTIONAL
%
%
% BASIC INPUTS
%
%   - Legend:             Simulation names that are shown in legend of figure,
%                         again provided in list as for Simulations (Legend entry 1
%                         refers to Simulation entry 1 and so on). Default: Legend = Simulation names
%
%   - ToPlot:             Variables to be plotted provided as list -can
%                         contain operators such as +,-,*,/,log,(
%                         ),numbers; To refer to parameters use e.g.
%                         Param.omega; To refer to the steady state use
%                         e.g. SS.Y
%                         Default: {'log(Y)','N', 'U', 'log(W)', 'pi', 'R', 'G_C/Y', ...
%                                  'log(RER)', 'log(C),log(C_R),log(C_L)', 'log(X)', 'log(IM)', 'log(I)'}
%
%
%   - Plot_Titles:        Provide titles of Plots as list
%                         Default no Titles;
%
%   - Periods:            Number of periods to show
%
%   - xAxis:              Either 'y' for years or 'q' for quarter (default)
%
%   - XLSoutput           If set to 1, an XLS file will be created containing
%                         the results of the simulation; setting to 1 will
%                         slow down function a lot. (set to 0 by default)
%
%
% ADVANCED INPUTS - only recommended for advanced users
%
%
%   - Plots_Horizontally:   How many subplots will be positioned next to each
%                           other - no Default: will be set automatically according to number
%                           of ToPlot
%
%   - Plots_Vertically:     How many subplots will be positioned above each
%                           other - Default: will be set automatically according to number
%                           of ToPlot
%
%   - SS_Period_Adds:       Array with integers. The xth integer indicates in
%                           which period the IRF's response begins in the
%                           plots. Useful for comparing anticipated and
%                           unanticpated runs. Array has to have the same
%                           dimension as Simulations.
%                           - Default: {0,0,0,0,0,0,0,0,0,0};
%
%   - Abs_Val:              for 0 (Default) plots will show deviations from steady-state
%                           for 1 plots will show absolute values of variables
%
%   - SS_Table:             for 0 no steady state (SS) table is shown
%                           for 1 (Default) SS table is shown:
%                           Two table of SS changes are shown, one for the percentage
%                           change of variables and one for the absolute
%                           change. The latter is useful for variables
%                           expresssed already in rates.
%
%   - TextFontSize          Size of Legend and PlotTitles
%
%   - Linewidth             Thickness of Lines (integer value, default is 3)
%
%   - LineStyle             Array of LineStyle to be applied to the
%                           simulations, e.g. {'-',':'} -> in this case
%                           experiment 1 will have a solid line, while
%                           experiment 2 will be dotted
%
%   - LineColor             Matrix with three columns and up to 10 rows.
%                           Each row contains the RGB code for a number.
%                           This color will be applied to the plot of the
%                           corresponding simulation (see "MatlabColors"
%                           below as an example)
%
%   - ShowLegend            If set to 0, no Legend will be shown below
%                           plots (default is 1)
%
%   - fullscreen           If set to 1 (which is the default), the plot
%                           window will be fullscreen. If set to 2, the
%                           plot window will be about half the screen. If
%                           set to 3, the plot window will be medium-sized
%
%   - showCols              If set to 1, then
%                           columns will appear at the end of a plot
%                           indicating the end SS value for a simulation.
%                           If set to 0 (defualt), these columns are not shown. (This
%                           only is relevant for permanent simulations and
%                           if only one a single simulation is plotted)
%
% Output:
%
% Plot of the IRF for time horizon 1 to Periods
%
% Examples:         1) Simple Example: PlotSimulationResults({'Run1','Run2'});
%
%                   2) PlotSimulationResults({'Run1','Run2'},'ToPlot',{'Y-SS.Y','Param.omega*C_L','R','pi','RER'});
%
%                   2) Example using multiple posibble inputs:
%                   PlotSimulationResults({'Run1','Run2'},...
%                       'ToPlot',{'log(G_C)', 'log(Y)' ,'R','N'},...
%                       'Plot_Titles',{'Purchases', 'GDP' ,'Interest rate','Employment rate'},...
%                       'Legend',{'Run 1', 'Run 2'},...
%                       'Abs_Val',1,'SS_Table',0,...
%                       'Plots_Horizontally',4,'Plots_Vertically',2);
%                   Simulations always first, remaining order does not
%                   matter!
%
% Written by Ivan Frankovic, 10/10/2018





% Default Values for optional inputs
defaultLegend = Simulations;
defaultToPlot = {'EXK', 'Y', 'Ym', 'E', 'EL', 'EF', 'K', 'KL',
    'KF', 'L', 'I', 'C', 'G', 'Qk', 'QkF', 'QkL'};
defaultPeriods = 40;
defaultPlots_Horizontally = 0;
defaultPlots_Vertically = 0;
defaultSS_Period_Adds = {0,0,0,0,0,0,0,0,0,0};
defaultAbs_Val = 0;
defaultPlot_Titles = {''};
defaultSS_Table = 0;
defaultLineStyle = {'-','-','-','-','-','-','-','-','-','-'};
MatlabColors=[           0.8500, 0.3250, 0.0980;
    0    0.4470    0.7410;
    0.9290    0.6940    0.1250;
    0.4940    0.1840    0.5560;
    0.4660    0.6740    0.1880;
    0.3010    0.7450    0.9330;
    0.6350    0.0780    0.1840];

%MagnusRequestedGreen = [0,128,0]/255;
defaultLineColor = {MatlabColors(1,:),MatlabColors(2,:),MatlabColors(3,:),MatlabColors(4,:),MatlabColors(5,:),MatlabColors(6,:)};
defaultxAxis = 'q';
defaultShowLegend = true;
defaultTextFontSize = 16;
defaultLinewidth = 3;
defaultfullscreen = 1;
defaultshowCols = 0;
defaultXLSoutput = 0;
defaultBase = '';
defaultNoSteadyStateLine = 1; % always plot "Steady State" line

% Parse function inputs
p = inputParser;
addRequired(p,'Simulations');
addOptional(p,'Legend',defaultLegend,@iscell);
addOptional(p,'ToPlot',defaultToPlot,@iscell);
addOptional(p,'Periods',defaultPeriods,@isnumeric);
addOptional(p,'Plots_Horizontally',defaultPlots_Horizontally,@isnumeric);
addOptional(p,'Plots_Vertically',defaultPlots_Vertically,@isnumeric);
addOptional(p,'SS_Period_Adds',defaultSS_Period_Adds,@iscell);
addOptional(p,'Abs_Val',defaultAbs_Val,@isnumeric);
addOptional(p,'Plot_Titles',defaultPlot_Titles,@iscell);
addOptional(p,'SS_Table',defaultSS_Table,@isnumeric);
addOptional(p,'LineStyle',defaultLineStyle,@iscell);
addOptional(p,'LineColor',defaultLineColor,@iscell);
addOptional(p,'xAxis',defaultxAxis,@isstr);
addOptional(p,'ShowLegend',defaultShowLegend,@isnumeric);
addOptional(p,'TextFontSize',defaultTextFontSize,@isnumeric);
addOptional(p,'Linewidth',defaultLinewidth,@isnumeric);
addOptional(p,'fullscreen',defaultfullscreen,@isnumeric);
addOptional(p,'showCols',defaultshowCols,@isnumeric);
addOptional(p,'XLSoutput',defaultXLSoutput,@isnumeric);
addOptional(p,'Base',defaultBase,@isstr);
addOptional(p,'NoSteadyStateLine',defaultNoSteadyStateLine,@isnumeric);
p.KeepUnmatched = true;
parse(p,Simulations,varargin{:})

% Load function inputs into corrspondings vars
Legend=p.Results.Legend;
ToPlot=p.Results.ToPlot;
Periods=p.Results.Periods;
Plots_Horizontally=p.Results.Plots_Horizontally;
Plots_Vertically=p.Results.Plots_Vertically;
SS_Period_Adds=p.Results.SS_Period_Adds;
Abs_Val=p.Results.Abs_Val;
Plot_Titles=p.Results.Plot_Titles;
SS_Table=p.Results.SS_Table;
LineStyle=p.Results.LineStyle;
LineColor=p.Results.LineColor;
xAxis=p.Results.xAxis;
ShowLegend=p.Results.ShowLegend;
TextFontSize=p.Results.TextFontSize;
Linewidth=p.Results.Linewidth;
fullscreen=p.Results.fullscreen;
showCols =p.Results.showCols;
XLSoutput = p.Results.XLSoutput;
Base = p.Results.Base;
NoSteadyStateLine = p.Results.NoSteadyStateLine;

% Checks
if numel(Simulations) > 10
    error('ERROR: You can at most plot 10 Simulations at the same time.');
end

if ~isequal(Plot_Titles,{''})
    if numel(ToPlot) ~= numel(Plot_Titles)
        error('ERROR: ToPlot and Plot_Titles need to have same dimension');
    end
end

% To make sure Legend has 10 entries
Legend_extended = {'','','','','','','','','',''};
for i=1:numel(Legend)
    Legend_extended(i) = Legend(i);
end



% ToPlot String Manipulation
% add . before algebraic symbols (for vector calculations in MATLAB need
% a.*b not just a*b)
for iToPlot = 1:numel(ToPlot)
    ToPlot_Matlab{iToPlot} = strrep(ToPlot{iToPlot},'*','.*');
    ToPlot_Matlab{iToPlot} = strrep(ToPlot_Matlab{iToPlot},'/','./');
end

% Construct layers of ToPlot
ToPlot_Layer = cell(4,numel(ToPlot));
N_Layer = 1;
for iToPlot = 1:numel(ToPlot_Matlab)
    ToPlotVars = strsplit(char(ToPlot_Matlab(iToPlot)),',');
    if numel(ToPlotVars) > 4
        error('ERROR: You can at most plot 4 Vars into one subgraph.');
    end
    if numel(ToPlotVars) > N_Layer
        N_Layer = numel(ToPlotVars);
    end
    for iLayer = 1:numel(ToPlotVars)
        ToPlot_Layer(iLayer,iToPlot) = ToPlotVars(iLayer);
    end
end
%ToPlot_Layer(1,:) contains first plots per subgraph
%ToPlot_Layer(2,:) contains second plots per subgraph and so on


% Prepare Vars
N_Simulations       = numel(Simulations);
N_IRFs              = numel(ToPlot_Matlab);
Result_all_Runs     = zeros(N_Layer,N_Simulations,N_IRFs,Periods);
Init_SS_all_Runs    = zeros(N_Layer,N_Simulations,N_IRFs);
Per75_all_Runs      = zeros(N_Layer,N_Simulations,N_IRFs);
Per100_all_Runs 	= zeros(N_Layer,N_Simulations,N_IRFs);
End_SS_all_Runs     = zeros(N_Layer,N_Simulations,N_IRFs);
SS_change_rel       = zeros(N_Layer,N_Simulations,N_IRFs);
SS_change_abs       = zeros(N_Layer,N_Simulations,N_IRFs);

% Function handles
gq   = @(x) [x(1:end)] ./[x(1) x(1:end-1)]; %Quarter growth Rate
lag  = @(x) [x(1) x(1:end-1)];
lead = @(x) [x(2:end) x(end)];
ptc  = @(x) 100*[x-x(1)]/x(1);
ann  = @(x) x.^4;


% load Base
if Base ~= ""
    SimulationPath = strcat('simulations/',Base,'.mat');
    if ~exist(SimulationPath)
        error(strcat('ERROR: Simulation "',Base,'" does not exist in the subfolder simulations.'));
    end
    Base_Results = load(SimulationPath);
    BaseIRFs    = Base_Results.IrfVectors;
end

for iSim = 1:N_Simulations
    Run_Name = cell2mat(Simulations(iSim));
    SS_Period_Add = cell2mat(SS_Period_Adds(iSim));
    SimulationPath = strcat('simulations/',Run_Name,'.mat');

    %check if Simulations exist
    if ~exist(SimulationPath)
        error(strcat('ERROR: Simulation "',Run_Name,'" does not exist in the subfolder simulations.'));
    end

    Simulation = load(SimulationPath);
    SimIRFs    = Simulation.IrfVectors ;
    SimVars    = Simulation.M_.endo_names;
    N_Mod_Vars = Simulation.M_.endo_nbr;
    SimType       = Simulation.SimType;
    %    if isstruct(Simulation.SimulationParameter)
    %        Param      = Simulation.SimulationParameter.Parameter;
    %        SS         = Simulation.SimulationParameter.SS;
    %    end

    for j=1:N_Mod_Vars
        eval( [ strtrim(char(SimVars(j,:))) '=  SimIRFs(j,:);'      ]);
    end

    % Output results as CSV
    if XLSoutput
        warning ('off','all');
        filename     = strcat('simulations/',Run_Name,'.xlsx');
        xlswrite(filename,{'RAW: This sheet contains the raw values for each variable.'},1,'A1')
        xlswrite(filename,{'Variable Name'},1,'A2')
        xlswrite(filename,[0:size(SimIRFs,2)-1],1,'B2')
        writetable(table(SimVars,SimIRFs),filename,'Sheet',1,'Range','A3','WriteVariableNames',false);

        xlswrite(filename,{'DEV: This sheet contains the variables deviation from steady state, e.g. Y-steady_state(Y).'},2,'A1')
        xlswrite(filename,{'Variable Name'},2,'A2')
        xlswrite(filename,[0:size(SimIRFs,2)-1],2,'B2')
        writetable(table(SimVars,SimIRFs-SimIRFs(:,1)),filename,'Sheet',2,'Range','A3','WriteVariableNames',false);

        xlswrite(filename,{'PercDEV: This sheet contains the variables percentage deviation from steady state, e.g. 100*(Y-steady_state(Y))/steady_state(Y).'},3,'A1')
        xlswrite(filename,{'Variable Name'},3,'A2')
        xlswrite(filename,[0:size(SimIRFs,2)-1],3,'B2')
        writetable(table(SimVars,100*(SimIRFs-SimIRFs(:,1))./SimIRFs(:,1)),filename,'Sheet',3,'Range','A3','WriteVariableNames',false);
        warning ('on','all');
    end

    % Create nominal Price variable
    P = zeros(1,numel(pi));
    P(1) = 1;
    for iT = 1:numel(pi)-1
        P(iT+1) = P(iT) * pi(iT);
    end


    for iToPlot = 1:numel(ToPlot_Matlab)
        for iLayer = 1:N_Layer
            if isequal(ToPlot_Layer(iLayer,iToPlot),{[]}) == 0
                eval( [ 'FullIRF = '  strjoin(ToPlot_Layer(iLayer,iToPlot)) ';' ]);
                Result_all_Runs(iLayer,iSim,iToPlot,:)          = FullIRF(1,1:Periods);
                if SimType == 'd'
                    Init_SS_all_Runs(iLayer,iSim,iToPlot)           = FullIRF(1,1);
                elseif SimType == 's'
                    Init_SS_all_Runs(iLayer,iSim,iToPlot)           = FullIRF(1,end);
                end
                End_SS_all_Runs(iLayer,iSim,iToPlot)            = FullIRF(1,end);
                Per75_all_Runs(iLayer,iSim,iToPlot)             = FullIRF(1,75);
                Per100_all_Runs(iLayer,iSim,iToPlot)            = FullIRF(1,100);
                Result_all_Runs(iLayer,iSim,iToPlot,:)          = [ones(1,SS_Period_Add)*Init_SS_all_Runs(iLayer,iSim,iToPlot) FullIRF(1,1:Periods-SS_Period_Add)]' ;

                SS_change_rel(iLayer,iToPlot,iSim) = round((End_SS_all_Runs(iLayer,iSim,iToPlot)-Init_SS_all_Runs(iLayer,iSim,iToPlot))/Init_SS_all_Runs(iLayer,iSim,iToPlot),4); %Percentage change
                SS_change_abs(iLayer,iToPlot,iSim) = round(End_SS_all_Runs(iLayer,iSim,iToPlot)-Init_SS_all_Runs(iLayer,iSim,iToPlot),4);
            end
        end
    end

end


%% Plotting
% close all;
Pix_SS = get(0,'screensize');
width = Pix_SS(3);
height = Pix_SS(4);
if fullscreen == 1
    figure('units','normalized','outerposition',[0 0 1 1])
elseif fullscreen == 2
    figure('Position', [100 20 width/2 height-100])
elseif fullscreen == 3
    figure('Position', [100 100 1000 800])
elseif fullscreen == 4
    %figure('Position', [100 100 1000 300])
    figure('units','normalized','outerposition',[0 0 1 0.5])
elseif fullscreen == 5
    figure('Position', [100 100 500 500])
elseif fullscreen == 6
    figure('units','normalized','outerposition',[0 0 1 0.35])
end

% set Number of Plots_Horizontally and Plots_Vertically
if Plots_Horizontally == 0 % only set if not given by use
    if N_IRFs < 3
        Plots_Horizontally = 2; Plots_Vertically = 1;
    elseif N_IRFs < 5
        Plots_Horizontally = 2; Plots_Vertically = 2;
    elseif N_IRFs < 7
        Plots_Horizontally = 3; Plots_Vertically = 2;
    elseif N_IRFs < 10
        Plots_Horizontally = 3; Plots_Vertically = 3;
    elseif N_IRFs < 13
        Plots_Horizontally = 4; Plots_Vertically = 3;
    elseif N_IRFs < 17
        Plots_Horizontally = 4; Plots_Vertically = 4;
    elseif N_IRFs < 21
        Plots_Horizontally = 5; Plots_Vertically = 4;
    elseif N_IRFs < 26
        Plots_Horizontally = 5; Plots_Vertically = 5;
    else
        Plots_Horizontally = 6; Plots_Vertically = 6;
    end
end

% Determine x-Axis
if xAxis == 'q'
    xNum = Periods-1;
    xx = 0:xNum;
    xlabeltext = 'quarters';
elseif xAxis == 'y'
    xNum =(Periods-1)/4;
    xx = 0:0.25:xNum;
    xlabeltext = 'years';
end

LineStyleLayer = {'--',':','-.'};

SubplotNumber = 1;
for i=1:N_IRFs

    if any(any(abs(squeeze(Result_all_Runs(1,:,i,:))- squeeze(Init_SS_all_Runs(1,:,i))')>1E-12))

        subplot(Plots_Vertically,Plots_Horizontally,SubplotNumber);
        ToPlotVars = strsplit(char(ToPlot_Matlab(i)),',');

        for iLayer = 1:numel(ToPlotVars)

            if iLayer == 1
                % since I am plotting steady state as first line, need to reorder
                % colors to make second line blue and so on
                oldColorOrder = get(gca,'colororder');
                newColorOrder = [ 0 0 0; oldColorOrder(1:end-1,:)];
                set(gca, 'ColorOrder', newColorOrder, 'NextPlot', 'replacechildren');

                if Abs_Val == 0
                        pl=plot(xx,squeeze(Result_all_Runs(iLayer,:,i,:)) - squeeze(Init_SS_all_Runs(iLayer,:,i))' ,'linewidth',Linewidth);
                        hold on
                        for NN = 1:N_Simulations
                            set(pl(NN),'LineStyle',LineStyle{NN},'Color',LineColor{NN});
                        end
                        if numel(ToPlotVars) > 1
                            text(xNum-0.5,Result_all_Runs(iLayer,1,i,Periods) - Init_SS_all_Runs(iLayer,1,i),ToPlotVars(iLayer),'FontSize',TextFontSize,'Interpreter','none')
                        end
                        if NoSteadyStateLine==0
                            p1=plot(xx,zeros(1,Periods)*Init_SS_all_Runs(iLayer,1,i),'linewidth',1,'linestyle','-','Color',[0/255 0/255 0/255]);
                        end
                        hold off

                else
                    p1=plot(xx,ones(1,Periods)*Init_SS_all_Runs(iLayer,1,i),'linewidth',1,'linestyle','-','Color',[0/255 0/255 0/255]);
                    hold on
                    pl=plot(xx,squeeze(Result_all_Runs(iLayer,:,i,:))','linewidth',Linewidth);
                    for NN = 1:N_Simulations
                        set(pl(NN),'LineStyle',LineStyle{NN},'Color',LineColor{NN});
                    end
                    if numel(ToPlotVars) > 1
                        text(xNum-0.5,Result_all_Runs(iLayer,1,i,Periods),ToPlotVars(iLayer),'FontSize',TextFontSize,'Interpreter','none')
                    end
                    hold off
                end

                ax = gca;
                ax.YAxis.Exponent = 0;


                grid on;

                %                 set(pl,'color','red')
            end


            if iLayer > 1
                newColorOrder = [ repmat( [0 0 0], N_Simulations*(iLayer-1) + 1, 1); oldColorOrder(1:end-N_Simulations*(iLayer-1) - 1,:)];
                set(gca, 'ColorOrder', newColorOrder, 'NextPlot', 'replacechildren');

                hold on
                if Abs_Val == 0
                    pl=plot(xx,squeeze(Result_all_Runs(iLayer,:,i,:)) - squeeze(Init_SS_all_Runs(iLayer,:,i))' ,'linewidth',Linewidth,'HandleVisibility','off','LineStyle',LineStyleLayer{iLayer});
                    text(xNum-0.5,Result_all_Runs(iLayer,1,i,Periods) - Init_SS_all_Runs(iLayer,1,i),ToPlotVars(iLayer),'FontSize',TextFontSize,'Interpreter','none')
                else
                    pl=plot(xx,squeeze(Result_all_Runs(iLayer,:,i,:))','linewidth',Linewidth,'HandleVisibility','off','LineStyle',LineStyleLayer{iLayer});
                    text(xNum-0.5,Result_all_Runs(iLayer,1,i,Periods),ToPlotVars(iLayer),'FontSize',TextFontSize,'Interpreter','none')
                end
                hold off

                ax = gca;
                ax.YAxis.Exponent = 0;

                %                 set(pl,'color','red')
            end





            if N_Simulations == 1 && N_Layer == 1
                if showCols
                    if Abs_Val == 0
                        hold on
                        line([xNum+2 xNum+2],[0 Per75_all_Runs(iLayer,1,i)-Init_SS_all_Runs(iLayer,1,i)],'linewidth',10,'Color',[51/255 201/255 51/255]);
                        line([xNum+5 xNum+5],[0 Per100_all_Runs(iLayer,1,i)-Init_SS_all_Runs(iLayer,1,i)],'linewidth',10,'Color',[0/255 153/255 51/255]);
                        line([xNum+8 xNum+8],[0 End_SS_all_Runs(iLayer,1,i)-Init_SS_all_Runs(iLayer,1,i)],'linewidth',10,'Color',[0/255 51/255 0/255]);
                        hold off;
                        xlim([0 xNum+10])
                    end
                end

                if SubplotNumber==1
                    w = warning ('off','all');
                    if ShowLegend
                        if xAxis == 'q'
                            legend('Zero Line','IRF','IRF in period 75','IRF in period 100','End steady-state','Location','best')
                        elseif xAxis == 'y'
                            legend('Zero Line','IRF','IRF in year 17.5','IRF in year 25','End steady-state','Location','best')
                        end
                    end
                    w = warning ('on','all');
                end


            end

            set(gca,'FontSize',TextFontSize-4)

            xlabel(xlabeltext,'FontSize',TextFontSize-4);


            if isequal(Plot_Titles,{''})
                title(ToPlot(i),'Interpreter', 'none','FontSize', TextFontSize);
            else
                title(Plot_Titles(i),'Interpreter', 'none','FontSize', TextFontSize);
            end


            if i==1 && N_Simulations > 1 && iLayer == 1 % BK changed manually to i==1 for Figure 1 ("_Spread")
                w = warning ('off','all');
                if ShowLegend
                    if fullscreen == 1
                        l=legend('Steady state',cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                            cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                            cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)),...
                            'Location','best');
                        if NoSteadyStateLine
                            l=legend(cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                                cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                                cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)),...
                                'Location','best');
                        end
                        set(l, 'Interpreter', 'none','FontSize',TextFontSize-2)
                    elseif fullscreen == 2
                        l=legend('Steady state',cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                            cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                            cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)),...
                            'Location','best');
                        if NoSteadyStateLine 
                            l=legend(cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                                cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                                cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)),...
                                'Location','best');
                        end
                        set(l, 'Interpreter', 'none','FontSize',TextFontSize-2)
                    else
                        legend('Steady state',cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                            cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                            cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)));
                        if NoSteadyStateLine
                            l=legend(cell2mat(Legend_extended(1)),cell2mat(Legend_extended(2)),cell2mat(Legend_extended(3)),cell2mat(Legend_extended(4)),...
                                cell2mat(Legend_extended(5)),cell2mat(Legend_extended(6)),cell2mat(Legend_extended(7)),cell2mat(Legend_extended(8)),...
                                cell2mat(Legend_extended(9)),cell2mat(Legend_extended(10)),...
                                'Location','best');
                        end

                    end

                end
                w = warning ('on','all');
            end

        end

        SubplotNumber = SubplotNumber +1;

    else
        ToPlotVars = strsplit(char(ToPlot_Matlab(i)),',');
        %warning([ char(ToPlotVars) ' does not deviate from steady state throughout the whole simulation horizon and is thus not plotted.']);
    end
end



%% Show Table for Layer1 only

iLayer=1;

% Reduce ToPlot to only first Layer
for iToPlot = 1:numel(ToPlot)
    ToPlotVars = strsplit(char(ToPlot_Matlab(iToPlot)),',');
    ToPlot(iToPlot) = ToPlotVars(1);
end

if SS_Table
    TableString_rel = 'transpose(ToPlot),';
    TableString_abs = 'transpose(ToPlot),';
    TableColumns = {N_Simulations + 1};
    TableColumns(1) = cellstr('Variable');
    for i = 1:N_Simulations
        Run_Name = cell2mat(Simulations(i));
        eval(strcat(Run_Name,'_SS_change_rel  =  SS_change_rel(iLayer,:,',num2str(i),');'));
        eval(strcat(Run_Name,'_SS_change_abs  =  SS_change_abs(iLayer,:,',num2str(i),');'));

        TableString_rel = strcat(TableString_rel,'transpose(',Run_Name,'_SS_change_rel),');
        TableString_abs = strcat(TableString_abs,'transpose(',Run_Name,'_SS_change_abs),');
        TableColumns(i+1) = cellstr(Run_Name);

    end
    TableString_rel = TableString_rel(1:end-1); %remove last comma
    TableString_abs = TableString_abs(1:end-1); %remove last comma
    eval([ 'Trel = table(' TableString_rel ');' ]);
    eval([ 'Tabs = table(' TableString_abs ');' ]);
    Trel.Properties.VariableNames = TableColumns;
    Tabs.Properties.VariableNames = TableColumns;

    disp('-------------------------------------------------------------------------------------')
    disp('    PERCENTAGE CHANGE OF VARIABLES FROM INITIAL TO END STEADY STATE, i.e. (END_SS-INIT_SS)/INIT_SS')
    disp('-------------------------------------------------------------------------------------')
    disp(Trel);
    disp('-------------------------------------------------------------------------------------')
    disp('    ABSOLUTE CHANGE OF VARIABLES FROM INITIAL TO END STEADY STATE, i.e. END_SS-INIT_SS ')
    disp('-------------------------------------------------------------------------------------')
    disp(Tabs);
end


