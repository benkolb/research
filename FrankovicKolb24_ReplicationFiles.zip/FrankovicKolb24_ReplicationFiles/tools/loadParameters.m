function param = loadParameters

    acS = 0.001; % this is almost identical to acS= 0 but runs through smoothly

    tau_SS = 75;

    UnDisclZ_L = 0.05*0.20; % Share of undisclosed emissions perceived to belong to low carbon sector
    UnDisclZ_Y = 1-UnDisclZ_L; % Share of undisclosed emissions perceived to belong to non-energy sector

    bet = 0.9954;   % discount factor                       % from Diluiso et al.
    alf = 0.36;     % capital share in production           % from Diluiso et al.
    del = 0.025;    % gross depreciation rate               % from Diluiso et al.
    delL= 0.020;    % gross depreciation rate               % from Diluiso et al.
    delF= 0.0125;   % gross depreciation rate               % from Diluiso et al.
    epsY= 0.6;%0.5  % Elas. of subst. between CD and E      % from Diluiso et al.
    epsE= 3;%5;     % Elas. of subst. between EL and EF     % from Diluiso et al.
    epsF= 0.15;%0.3 % Elas. of subst. between KF and X      % from Diluiso et al. 
    epsI_ss= 6;     % Elas. of subst. intermediate goods    % from Diluiso et al.
    tet = 0.9554;   % survival probability bankers          % from Diluiso et al.
    hab = 0.6326;   % habit parameter                       % from Diluiso et al.
    sig = 1.5365;   % intertemp. elasticity of substitution % from Diluiso et al.
    fri = 0.7223;   % Frisch labour elasticity              % from Diluiso et al.

    acI = 9.4913;   % adjustment cost parameter investment  % from Diluiso et al.
    acIL= 14.5498;  % adjustment cost parameter investment  % from Diluiso et al.
    acIF= 13.3921;  % adjustment cost parameter investment  % from Diluiso et al.
    % Taylor rule parameter from Diluiso et al.
    acP     = 54.5121;
    w_p     = 0.6018;
    rho_R   = 0.6571;
    rho_Y   = 0.0684;
    rho_pi  = 2.9985;

    % steady state calibration targets
    G_Share_Y       = 0.2051;               % SS government spending over GDP               % from Diluiso et al.
    EnCost_Share_Y  = 0.05;                 % Energy cost share                             % from Diluiso et al.
    Share_L_in_E    = 0.20;                 % Share of low-carbon in energy sector          % from Diluiso et al.
    Fossil_Share_Y  = 0.02+0.018;                % Share of fossil ressource expenditure in GDP  % from Diluiso et al.
    %this compromises fossil share and env. tax revenue share (2% from
    %https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Environmental_tax_statistics_-_detailed_analysis#Energy_taxes_stand_out_as_the_major_source_of_EU_environmental_tax_revenue)
    KappaSS         = 0.09;                 % risk-weighted capital ratio
    SPRSS           = 0.0032;               % ... spread Rk-R                               % from Diluiso et al.
    SPRFSS          = 0.0035;               % ... spread RF-R                               % from Diluiso et al.
    SPRLSS          = 0.0040;               % ... spread RL-R                               % from Diluiso et al.    
    pi_SS           = 1.0047;   


    % Calibrating tau conversion factor
    EmissionCost_1EuroCarbonPrice = 0.000261194; % Given empirical values for GHG emissions and GDP in 2020 in EU calculate the cost of
                                                 % emission as share of GDP in case of 1 Euro carbon price per tonne
    eI_F = 0;   %set in SS
    D_SS = 1;   %initial disclosure level

    GER_Calibration = 0;
    if GER_Calibration
        alf     = 0.33;
        bet     = 0.995;
        sig     = 2.68;
        hab     = 0.37;
        G_Share_Y       = 0.25;
        EnCost_Share_Y  = 0.05;
        Share_L_in_E    = 0.17;
        Fossil_Share_Y  = 0.02;
    end

    MCSS            = (epsI_ss-1)/epsI_ss;        % steady-state marginal cost
    Cost_Share_Y    = MCSS;                 % Share of total production cost over GDP
    EnCost_Share_YCost = EnCost_Share_Y / Cost_Share_Y; % Energy cost as percent over GDP Y as opposed to over total production cost MC*Y
    CapLab_Share    = 1-EnCost_Share_YCost; % Capital-Labor income share                    % follows from above    
    CapInc_Share    = alf*CapLab_Share;     % Capital income                                % follows from above
    LabInc_Share    = (1-alf)*CapLab_Share; % Labor income share                            % follows from above
    

    w_CD    = 0.90;
    w_EL_SS = Share_L_in_E;
    w_KF    = 0.7;

    % persistence (rho) and standard deviation (sig) of ...
    rho_i = 0;   	% ... investment-specific shock
    sig_i = 0.01;
    rho_k = 0.75;	% ... capital efficiency shock
    sig_k = 0.05;
    sig_kl = 0.05;
    sig_kf = 0.05;
    rho_a = 0*0.95;	% ... TFP shock
    sig_a = 0.01;
    rho_g = 0.95;  	% ... government spending shock
    sig_g = 0.01;
    rho_p = 0.66;	% ... intertemp. preference shock
    sig_p = 0.072;
    sig_n = 0.01;	% ... net worth shock (rho_n=0)
    rho_tau = 0;
    sig_tau = 1;
    sig_R = 1;
    rho_pf = 0;
    sig_pf = 1;
    rho_c  = 0.5;
    sig_c  = 1;
    rho_epsi = 0.5;
    sig_epsi = 1;



    % Following values set in SS file
    GSS = 0; 
    P_FSS=0;
    ISS  =0; 
    ILSS =0; 
    IFSS =0;
    RnSS =0;

    P_EF_SS = 0;
    EF_SS   = 0;
    P_EL_SS = 0;
    EL_SS   = 0;
    L_SS = 0;

    omg     = 5.6817e-04;   % ... share of net worth to new banks
    rho_SS  = 0.3853;       % ... share of divertable assets
    rhoL_SS = 1.2500;
    rhoF_SS = 1.0938;
    chi     = 24.9630;      % ... labour disutility parameter  
    
    s_SS   = 0;
    sL_SS  = 0;
    sF_SS  = 0;
    aY  = 0;
    aL  = 0;
    aF  = 0;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% SAVING
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    save('tools/Param.mat');
    %create ParamList to be copied in mod file
    param = load('tools/Param.mat');
    pnames = fieldnames(param);
    parnr  = length(pnames);
    ParamListString = deblank(pnames{1});
    for j = 2:parnr
       pname = deblank(pnames{j});
       if mod(j,1) == 0
            ParamListString = [ParamListString newline pname];
       else
            ParamListString = [ParamListString ' ' pname];
       end
    end
    fileID = fopen('tools/Include_Params.mod','w');
    fprintf(fileID, ParamListString);
    fclose(fileID);

end